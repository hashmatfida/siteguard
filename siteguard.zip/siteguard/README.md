# SiteGuard — Local Security Advisor (browser extension)

A working Manifest V3 browser extension implementing the **local/passive tier**
of the "AI-Powered Browser Security Extension" architecture document: it
scans every page you visit for HTTPS/TLS issues, weak security headers,
insecure cookies, mixed content, suspicious redirect chains, phishing-style
URL patterns, and suspicious forms/scripts — entirely on your device — and
gives you a transparent 0–100 risk score with an evidence-based explanation.

**Status: tested and working** in a real, unpacked Chrome load (see "How this
was tested" below). Ready to load today. It is *not* published to the Chrome
Web Store — see "Publishing" for that separate process.

## What's real here, and what's a documented stub

This build implements everything in the architecture doc marked **"Local"**
evaluation location: header/cookie/CSP/TLS checks, mixed content, redirect
chains, URL/typosquat heuristics, suspicious forms, script-obfuscation
heuristics, hidden iframes, and passive information-exposure checks — plus
the full risk-scoring formula, the confidence/evidence-quality blocking gate,
the XAI explanation layer, warn/block UI, local history, and denylist
enforcement via `declarativeNetRequest`.

What is **not** included, and why:

- **No trained ML classifier or live threat-intel feeds.** Those require a
  labeled dataset and API credentials that are yours to obtain, not something
  that can be faked convincingly. Instead, `lib/heuristics.js` includes a
  small, clearly-labeled local heuristic (Levenshtein distance to ~20 common
  brand domains) as a stand-in for the phishing-classifier described in the
  doc, and every finding it produces is tagged `evidenceType: 'inference'`
  with a reduced confidence score — never presented as more certain than it is.
- **Backend hook, not a backend.** `background.js` will POST a minimized
  feature vector to `Settings → Backend URL` (`/v1/scan/quick`, matching the
  architecture doc's §11.3 schema) if you configure one, and will merge
  returned findings into the score, tagged as external/inference evidence.
  Leave it blank and the extension is 100% local — this is the default.
  Build the backend from the architecture document to light this up.
- **Not published/signed.** Loading as an unpacked extension (below) is the
  fastest path to actually using it. Store submission is a separate step
  with its own review process — see "Publishing," below.

## Install (load unpacked)

1. Unzip this folder somewhere permanent (don't load it from a temp folder
   you'll delete).
2. Chrome/Edge: go to `chrome://extensions` (or `edge://extensions`), enable
   **Developer mode** (top right), click **Load unpacked**, and select the
   `siteguard` folder.
3. Pin the SiteGuard icon (puzzle-piece icon → pin) for easy access.
4. Visit any http/https page. The toolbar badge shows a score after a moment;
   click the icon for the summary, "View detailed report" for the full
   evidence-based report.

Firefox: Manifest V3 support (service workers, `declarativeNetRequest`) is
still catching up across Firefox versions. This build targets Chromium
(Chrome/Edge/Brave/Opera). A Firefox port would mainly need `background.
service_worker` swapped for an event page and `declarativeNetRequest`
behavior re-verified.

## Permissions this extension requests, and why

| Permission | Why |
|---|---|
| `storage` | Save your settings and local scan history on-device |
| `activeTab` | Read basic info about the tab you're currently viewing |
| `webRequest` (read-only) | Read response headers (CSP, HSTS, Set-Cookie attributes, CORS) — never modifies requests |
| `webNavigation` | Detect redirect chains |
| `declarativeNetRequest` | Block domains on your personal block list before they load |
| `alarms` | Reserved for periodic optional-backend refresh |
| `host_permissions: http://*/*, https://*/*` | Needed for the header/DOM inspection above to run on the pages you actually visit |

Deliberately **not** requested: `cookies` (cookie attributes are read from
response headers instead, never cookie values), `history`, `tabs`, `downloads`,
`scripting` (the content script is statically declared, not dynamically
injected).

## How this was tested

Built and verified in this session with a real unpacked load in headless
Chrome (Puppeteer + the actual Chrome binary, `--load-extension`), against a
local test server serving deliberately good/bad pages, plus direct
`chrome.storage` inspection to avoid UI-timing flakiness in headless mode.
Confirmed:

- **Clean HTTPS page** (proper headers, secure cookie, no mixed content) →
  score **0**, "Very Low", 0 findings.
- **Deliberately insecure HTTP page** (no security headers, insecure cookie,
  password form posting over HTTP, mixed content, obfuscated inline script,
  links to `.git/config` / `.env`) → score **73**, "High", **11 findings**,
  action **block** — and the in-page blocking overlay rendered correctly
  (screenshotted), the detailed report page rendered all findings with
  correct severity/CWE/remediation/evidence-type labeling.
- **Redirect chains**: a 2-hop cross-domain redirect was correctly detected
  and added as a finding.
- **Allow-list**: adding a domain to the allow list correctly forces
  `action: allow, score: 0`, bypassing the scan entirely (no false sense of
  danger for sites you've explicitly trusted).
- **Block-list**: adding a domain to the block list correctly synced a
  `declarativeNetRequest` dynamic rule, and the browser genuinely refused to
  load that domain (`net::ERR_BLOCKED_BY_CLIENT`) — real network-layer
  blocking, confirmed, not just a UI state.
- Unit-level: the anti-flooding scoring formula and the confidence/evidence-
  quality blocking gate were verified against the architecture doc's worked
  examples (one Critical finding scores ~40; twenty Informational findings
  together score ~2; low-confidence/low-evidence-quality findings correctly
  fail to trigger a block even at a high raw score).

What I did **not** get to in this session: automated screenshot-level
verification of every popup state in headless mode (some scenarios hit
headless-Chrome-specific `networkidle0`/reload flakiness in my *test
harness* — not in the extension — which I worked around by reading
`chrome.storage` directly instead). I'd recommend a manual click-through
before wide deployment, and treat this as a solid, working first version
rather than an exhaustively QA'd release.

## Settings quick-reference

Open via the ⚙ icon in the popup, or `chrome://extensions` → SiteGuard →
Details → Extension options.

- **Mode**: Automatic (scans every page) or Manual (only on click/rescan).
- **Sensitivity**: shifts the warn/block score floors — Strict (25/50),
  Balanced (35/60, default), Relaxed (45/75).
- **Show blocking interstitial**: off = warning banner only, even for
  High/Critical.
- **Allow/block lists**: per-domain overrides.
- **History retention**: 7/30/90/365 days, or clear it all with one click.
- **Backend URL / token**: optional, see above.

## Extending this

- **lib/rules.js** — add a new check: push a `finding({...})` with a
  `severity`, `confidence`, `evidenceQuality`, `evidence` string, and
  `remediation`. It flows automatically into scoring, XAI, the popup, and
  the report.
- **lib/scoring.js** — the decay-weighted formula and the block gate live
  here, matching architecture doc §4 exactly; thresholds are in
  `lib/storage.js` (`SENSITIVITY_THRESHOLDS`).
- **Backend** — build the FastAPI service from the architecture document;
  point `Settings → Backend URL` at `/v1/scan/quick` and its response
  format (see `background.js`'s `queryBackend()`) already matches the
  doc's §11.3 schema.

## Publishing to the Chrome Web Store (separate, manual step)

This is not done for you — it requires a Google-verified developer account
(one-time fee), your own listing copy/screenshots, and passing Chrome Web
Store review (which specifically scrutinizes broad host permissions and
`declarativeNetRequest` use, both of which this extension has for good
reason — be ready to explain them in the review notes, and consider whether
`optional_host_permissions` per-site opt-in, mentioned as a future direction
in the architecture doc §10.1, would ease that review). To package for
upload: zip the contents of this folder (not the folder itself) into a
`.zip` and upload via the Chrome Developer Dashboard.
