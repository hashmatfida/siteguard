// SiteGuard — content script.
// Runs once per top-level page load (see manifest: all_frames=false).
// Job 1: passively collect DOM-visible signals and hand them to the
//         background service worker (no fetching of third-party script
//         bodies beyond a best-effort same-load read; never sends cookie
//         VALUES, only what response headers already exposed to it).
// Job 2: render the warn/block UI inline, isolated in a Shadow DOM so we
//         never collide with the host page's styles.

(function () {
  if (window.__siteguardInjected) return;
  window.__siteguardInjected = true;

  const SENSITIVE_PATH_RE = [
    /\.git\/(config|HEAD)(\?|$)/i,
    /\.env(\.|\?|$)/i,
    /wp-config\.php(\.bak|\.old|~)?(\?|$)/i,
    /\.DS_Store$/i,
    /\/backup(\.zip|\.tar\.gz|\.sql)(\?|$)/i,
    /web\.config(\.bak)?(\?|$)/i,
    /id_rsa(\.pub)?$/i,
  ];
  const ERROR_SIGNATURES = [
    /you have an error in your sql syntax/i,
    /warning:\s*mysqli?_/i,
    /unhandled exception/i,
    /traceback \(most recent call last\)/i,
    /System\.NullReferenceException/,
    /ORA-\d{5}:/,
    /PostgreSQL[^\n]{0,40}ERROR:/,
  ];
  const LOGIN_CONTEXT_RE = /log ?in|sign ?in|checkout|payment|card ?number|cvv|billing/i;

  function scriptObfuscationScore(text) {
    if (!text || text.length < 40) return { score: 0, reasons: [] };
    const reasons = [];
    let score = 0;
    const evalCount = (text.match(/\beval\s*\(/g) || []).length;
    const funcCtorCount = (text.match(/\bFunction\s*\(/g) || []).length;
    const docWriteCount = (text.match(/document\.write\s*\(/g) || []).length;
    const longB64 = (text.match(/[A-Za-z0-9+/]{80,}={0,2}/g) || []).length;
    const escSeq = (text.match(/\\x[0-9a-fA-F]{2}/g) || []).length + (text.match(/\\u[0-9a-fA-F]{4}/g) || []).length;
    if (evalCount > 0) { score += Math.min(3, evalCount); reasons.push(`${evalCount} use(s) of eval()`); }
    if (funcCtorCount > 0) { score += Math.min(2, funcCtorCount); reasons.push(`${funcCtorCount} use(s) of Function()`); }
    if (docWriteCount > 2) { score += 1; reasons.push(`${docWriteCount} use(s) of document.write()`); }
    if (longB64 >= 1) { score += Math.min(2, longB64); reasons.push(`${longB64} long base64-like block(s)`); }
    if (escSeq > 20) { score += 2; reasons.push('dense hex/unicode escape sequences'); }
    return { score, reasons };
  }

  function collectSignals() {
    const pageIsHttps = location.protocol === 'https:';
    const forms = Array.from(document.forms).map((form) => {
      const hasPassword = !!form.querySelector('input[type="password"]');
      let actionUrl, actionIsCrossOrigin = false, actionIsHttp = false, actionOrigin = null;
      try {
        actionUrl = new URL(form.action || location.href, location.href);
        actionOrigin = actionUrl.origin;
        actionIsCrossOrigin = actionUrl.origin !== location.origin;
        actionIsHttp = actionUrl.protocol === 'http:';
      } catch (_) { /* ignore malformed action */ }
      return { hasPassword, actionIsCrossOrigin, actionIsHttp, actionOrigin };
    });

    const scriptEls = Array.from(document.querySelectorAll('script'));
    const thirdPartyScripts = [];
    const inlineScripts = [];
    for (const el of scriptEls) {
      if (el.src) {
        try {
          const u = new URL(el.src, location.href);
          if (u.origin !== location.origin) {
            thirdPartyScripts.push({ src: u.href, hostname: u.hostname });
          }
        } catch (_) {}
      } else if (el.textContent && el.textContent.length > 40) {
        inlineScripts.push({
          length: el.textContent.length,
          obfuscation: scriptObfuscationScore(el.textContent),
        });
      }
    }
    // de-dupe third-party script hostnames for the count-based heuristic
    const uniqueThirdPartyHosts = Array.from(new Set(thirdPartyScripts.map((s) => s.hostname)))
      .map((hostname) => ({ hostname }));

    const mixedContentResources = [];
    if (pageIsHttps) {
      const tagsToCheck = [
        ['img[src]', 'img', 'src'],
        ['script[src]', 'script', 'src'],
        ['iframe[src]', 'iframe', 'src'],
        ['link[rel="stylesheet"][href]', 'link', 'href'],
        ['video[src]', 'video', 'src'],
        ['audio[src]', 'audio', 'src'],
      ];
      for (const [selector, tag, attr] of tagsToCheck) {
        document.querySelectorAll(selector).forEach((el) => {
          const raw = el.getAttribute(attr);
          if (raw && /^http:\/\//i.test(raw)) {
            mixedContentResources.push({ tag, url: raw });
          }
        });
      }
    }

    const iframes = Array.from(document.querySelectorAll('iframe')).map((f) => {
      const rect = f.getBoundingClientRect();
      const style = window.getComputedStyle(f);
      const zeroSize = rect.width <= 1 || rect.height <= 1;
      const hidden = style.visibility === 'hidden' || style.display === 'none' || parseFloat(style.opacity || '1') === 0;
      return { hidden, zeroSize, src: f.getAttribute('src') || '' };
    });

    const links = Array.from(document.querySelectorAll('a[href]')).map((a) => a.getAttribute('href') || '');
    const sensitiveLinks = [];
    outer: for (const href of links) {
      for (const re of SENSITIVE_PATH_RE) {
        if (re.test(href)) { sensitiveLinks.push({ href }); break outer; }
      }
    }

    let bodyText = '';
    try { bodyText = (document.body && document.body.innerText || '').slice(0, 20000); } catch (_) {}
    const errorTextMatches = [];
    for (const re of ERROR_SIGNATURES) {
      const m = bodyText.match(re);
      if (m) { errorTextMatches.push(m[0]); break; }
    }

    const hasMetaRefresh = !!document.querySelector('meta[http-equiv="refresh" i]');
    const isLoginOrPaymentContext =
      forms.some((f) => f.hasPassword) || LOGIN_CONTEXT_RE.test(document.title + ' ' + location.href);

    return {
      forms,
      thirdPartyScripts: uniqueThirdPartyHosts,
      inlineScripts,
      mixedContentResources,
      iframes,
      sensitiveLinks,
      errorTextMatches,
      hasMetaRefresh,
      isLoginOrPaymentContext,
    };
  }

  function send() {
    try {
      chrome.runtime.sendMessage({ type: 'SG_SIGNALS', signals: collectSignals(), url: location.href }, () => {
        // Swallow "no receiving end" errors that can happen on extension reload.
        void chrome.runtime.lastError;
      });
    } catch (_) { /* extension context may be invalidated during reload */ }
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(send, 50);
  } else {
    document.addEventListener('DOMContentLoaded', () => setTimeout(send, 50));
  }

  // ---------------------------------------------------------------- UI overlay

  let shadowHost = null;
  let shadowRoot = null;

  function ensureShadow() {
    if (shadowRoot) return shadowRoot;
    shadowHost = document.createElement('div');
    shadowHost.id = 'siteguard-shadow-host';
    shadowHost.style.all = 'initial';
    document.documentElement.appendChild(shadowHost);
    shadowRoot = shadowHost.attachShadow({ mode: 'closed' });
    return shadowRoot;
  }

  function styles() {
    return `
      :host { all: initial; }
      * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; }
      .sg-banner {
        position: fixed; top: 0; left: 0; right: 0; z-index: 2147483000;
        background: #fff7e0; border-bottom: 3px solid #d9932c; color: #4a3a10;
        padding: 10px 16px; display: flex; align-items: center; gap: 12px;
        font-size: 13.5px; box-shadow: 0 2px 8px rgba(0,0,0,.15);
      }
      .sg-banner.critical { background: #fdecec; border-bottom-color: #c0392b; color: #4a1210; }
      .sg-banner .sg-icon { font-size: 18px; }
      .sg-banner .sg-msg { flex: 1; line-height: 1.4; }
      .sg-banner .sg-msg b { display:block; font-size: 14px; margin-bottom: 2px; }
      .sg-btn {
        border: 1px solid rgba(0,0,0,.2); background: rgba(255,255,255,.6); color: inherit;
        padding: 6px 12px; border-radius: 6px; font-size: 12.5px; cursor: pointer; white-space: nowrap;
      }
      .sg-btn.primary { background: #1b2a4a; color: #fff; border-color: #1b2a4a; }
      .sg-btn:hover { filter: brightness(0.95); }
      .sg-overlay {
        position: fixed; inset: 0; z-index: 2147483647; background: #10131c;
        display: flex; align-items: center; justify-content: center; padding: 24px;
      }
      .sg-card {
        max-width: 560px; width: 100%; background: #fff; border-radius: 12px; padding: 32px;
        box-shadow: 0 20px 60px rgba(0,0,0,.4); color: #1c2333;
      }
      .sg-card .sg-badge {
        display: inline-block; padding: 3px 10px; border-radius: 999px; font-size: 11.5px;
        font-weight: 700; letter-spacing: .04em; text-transform: uppercase; background: #fdecec; color: #a5241a;
        margin-bottom: 14px;
      }
      .sg-card h1 { font-size: 20px; margin: 0 0 8px 0; color: #1b1620; }
      .sg-card .sg-domain { font-size: 13px; color: #666; margin-bottom: 18px; word-break: break-all; }
      .sg-card .sg-score { font-size: 15px; margin-bottom: 14px; }
      .sg-card .sg-score b { font-size: 26px; }
      .sg-reasons { list-style: none; padding: 0; margin: 0 0 20px 0; }
      .sg-reasons li { padding: 9px 0; border-top: 1px solid #eee; font-size: 13px; }
      .sg-reasons li:first-child { border-top: none; }
      .sg-reasons .sg-tag {
        display: inline-block; font-size: 10.5px; font-weight: 700; text-transform: uppercase;
        padding: 1px 6px; border-radius: 4px; margin-right: 6px; background: #eef0f6; color: #445;
      }
      .sg-actions { display: flex; gap: 10px; margin-top: 22px; flex-wrap: wrap; }
      .sg-actions .sg-btn { flex: 1; text-align: center; padding: 10px 14px; font-size: 13.5px; }
      .sg-links { margin-top: 14px; font-size: 12px; color: #667; display:flex; gap: 14px; }
      .sg-links a { color: #445; cursor: pointer; text-decoration: underline; }
    `;
  }

  function reasonsHtml(factors) {
    return factors.slice(0, 4).map((f) => `
      <li>
        <span class="sg-tag">${f.contributionLabel}</span>
        <span class="sg-tag" style="background:#f4f6fb;color:#2b3a67;">${f.evidenceTypeLabel}</span>
        <div style="margin-top:4px;"><strong>${escapeHtml(f.title)}</strong></div>
        <div style="color:#556;margin-top:2px;">${escapeHtml(f.evidence)}</div>
      </li>
    `).join('');
  }

  function escapeHtml(s) {
    return (s || '').replace(/[&<>"']/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  }

  function showBanner(explanation) {
    const root = ensureShadow();
    const isCritical = explanation.band.key === 'critical';
    root.innerHTML = `<style>${styles()}</style>
      <div class="sg-banner ${isCritical ? 'critical' : ''}">
        <span class="sg-icon">${isCritical ? '⛔' : '⚠️'}</span>
        <div class="sg-msg">
          <b>${escapeHtml(explanation.headline)}</b>
          ${escapeHtml((explanation.factors[0] && explanation.factors[0].title) || '')}
        </div>
        <button class="sg-btn" id="sg-details">View details</button>
        <button class="sg-btn primary" id="sg-dismiss">Dismiss</button>
      </div>`;
    root.getElementById('sg-dismiss').onclick = () => hide();
    root.getElementById('sg-details').onclick = () => chrome.runtime.sendMessage({ type: 'SG_OPEN_REPORT' });
  }

  function showBlockOverlay(explanation, policyLocked) {
    const root = ensureShadow();
    root.innerHTML = `<style>${styles()}</style>
      <div class="sg-overlay">
        <div class="sg-card">
          <span class="sg-badge">${escapeHtml(explanation.band.label)} risk</span>
          <h1>This site was blocked by SiteGuard</h1>
          <div class="sg-domain">${escapeHtml(explanation.domain)}</div>
          <div class="sg-score">Risk score <b>${explanation.score}</b>/100 &middot; confidence ${Math.round((explanation.factors[0]?.confidence || 0.8) * 100)}%</div>
          <ul class="sg-reasons">${reasonsHtml(explanation.factors)}</ul>
          <div class="sg-actions">
            <button class="sg-btn primary" id="sg-back">Go back</button>
            ${policyLocked ? '' : '<button class="sg-btn" id="sg-continue">Continue anyway</button>'}
          </div>
          <div class="sg-links">
            <a id="sg-report">View detailed report</a>
            <a id="sg-fp">Report false positive</a>
          </div>
        </div>
      </div>`;
    root.getElementById('sg-back').onclick = () => { if (history.length > 1) history.back(); else window.close(); };
    const cont = root.getElementById('sg-continue');
    if (cont) cont.onclick = () => {
      chrome.runtime.sendMessage({ type: 'SG_ALLOW_ONCE', domain: explanation.domain });
      hide();
    };
    root.getElementById('sg-report').onclick = () => chrome.runtime.sendMessage({ type: 'SG_OPEN_REPORT' });
    root.getElementById('sg-fp').onclick = () => chrome.runtime.sendMessage({ type: 'SG_FALSE_POSITIVE', domain: explanation.domain });
  }

  function hide() {
    if (shadowHost) { shadowHost.remove(); shadowHost = null; shadowRoot = null; }
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'SG_SHOW_WARN') { showBanner(msg.explanation); sendResponse({ ok: true }); }
    if (msg.type === 'SG_SHOW_BLOCK') { showBlockOverlay(msg.explanation, msg.policyLocked); sendResponse({ ok: true }); }
    if (msg.type === 'SG_HIDE') { hide(); sendResponse({ ok: true }); }
    return true;
  });
})();
