// SiteGuard — background service worker.
// Orchestration only: header/redirect capture -> rule engine -> scoring ->
// XAI -> badge + overlay dispatch + local history. See README.md for the
// full data-flow description and the architecture doc this implements.

importScripts('lib/heuristics.js', 'lib/rules.js', 'lib/scoring.js', 'lib/xai.js', 'lib/storage.js');

const Storage = self.SiteGuardStorage;
const Rules = self.SiteGuardRules;
const Scoring = self.SiteGuardScoring;
const XAI = self.SiteGuardXAI;

// ---------------------------------------------------------------- per-tab in-memory state
// Ephemeral by design: rebuilt on every navigation, and it's fine if the
// service worker recycles between navigations (MV3 expectation). Long-lived
// data (history, settings) lives in chrome.storage, not here.
const pending = new Map();   // tabId -> { navId, url, hostname, protocol, headers, dom, redirect, analyzed }
const redirectChains = new Map(); // tabId -> [{ from, to }]
const allowOnce = new Map(); // domain -> expiry timestamp (ms)

function isHttpUrl(url) {
  return typeof url === 'string' && /^https?:\/\//i.test(url);
}

function domainOf(url) {
  try { return new URL(url).hostname; } catch (_) { return ''; }
}

// ---------------------------------------------------------------- header capture

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;
  redirectChains.set(details.tabId, []);
});

chrome.webRequest.onBeforeRedirect.addListener(
  (details) => {
    if (details.type !== 'main_frame') return;
    const chain = redirectChains.get(details.tabId) || [];
    chain.push({ from: details.url, to: details.redirectUrl });
    redirectChains.set(details.tabId, chain);
  },
  { urls: ['http://*/*', 'https://*/*'], types: ['main_frame'] }
);

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.type !== 'main_frame' || !isHttpUrl(details.url)) return;
    const parsed = parseHeaders(details.responseHeaders || []);
    const navId = `${details.tabId}:${details.url}:${Math.floor(Date.now() / 2000)}`;
    const entry = pending.get(details.tabId) || {};
    entry.navId = entry.navId || navId;
    entry.url = details.url;
    entry.hostname = domainOf(details.url);
    entry.protocol = details.url.startsWith('https') ? 'https:' : 'http:';
    entry.headers = parsed;
    entry.analyzed = false;
    pending.set(details.tabId, entry);
    maybeAnalyze(details.tabId);
  },
  { urls: ['http://*/*', 'https://*/*'], types: ['main_frame'] },
  ['responseHeaders', 'extraHeaders']
);

function parseHeaders(list) {
  const get = (name) => {
    const h = list.find((x) => x.name.toLowerCase() === name);
    return h ? h.value : null;
  };
  const setCookies = list.filter((x) => x.name.toLowerCase() === 'set-cookie').map((x) => x.value);
  return {
    csp: get('content-security-policy'),
    hsts: get('strict-transport-security'),
    xfo: get('x-frame-options'),
    xcto: get('x-content-type-options'),
    referrerPolicy: get('referrer-policy'),
    corsAllowOrigin: get('access-control-allow-origin'),
    corsAllowCredentials: get('access-control-allow-credentials'),
    cookies: setCookies.map(parseSetCookie),
  };
}

function parseSetCookie(raw) {
  const parts = raw.split(';').map((p) => p.trim());
  const [nameValue] = parts;
  const name = (nameValue || '').split('=')[0];
  const lower = parts.map((p) => p.toLowerCase());
  return {
    name,
    secure: lower.some((p) => p === 'secure'),
    httpOnly: lower.some((p) => p === 'httponly'),
    sameSite: lower.some((p) => p.startsWith('samesite')),
  };
}

// ---------------------------------------------------------------- content-script signals

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handleMessage(msg, sender).then(sendResponse).catch((err) => {
    console.error('SiteGuard message error', err);
    sendResponse({ ok: false, error: String(err) });
  });
  return true; // keep the channel open for the async response
});

async function handleMessage(msg, sender) {
  switch (msg.type) {
    case 'SG_SIGNALS': {
      const tabId = sender.tab?.id;
      if (tabId == null || !isHttpUrl(msg.url)) return { ok: false };
      const entry = pending.get(tabId) || {};
      entry.dom = msg.signals;
      entry.url = entry.url || msg.url;
      entry.hostname = entry.hostname || domainOf(msg.url);
      entry.protocol = entry.protocol || (msg.url.startsWith('https') ? 'https:' : 'http:');
      pending.set(tabId, entry);
      await maybeAnalyze(tabId);
      return { ok: true };
    }
    case 'SG_OPEN_REPORT': {
      const tabId = sender.tab?.id;
      const entry = tabId != null ? pending.get(tabId) : null;
      const domain = entry?.hostname || '';
      chrome.tabs.create({ url: chrome.runtime.getURL(`report/report.html?domain=${encodeURIComponent(domain)}`) });
      return { ok: true };
    }
    case 'SG_ALLOW_ONCE': {
      if (msg.domain) allowOnce.set(msg.domain, Date.now() + 30 * 60 * 1000); // 30 min
      return { ok: true };
    }
    case 'SG_FALSE_POSITIVE': {
      await Storage.recordFalsePositive({ domain: msg.domain, findingId: msg.findingId || null, source: msg.source || 'overlay' });
      return { ok: true };
    }
    case 'SG_GET_TAB_STATE': {
      const tabId = msg.tabId;
      const entry = tabId != null ? pending.get(tabId) : null;
      return { ok: true, ready: !!(entry && entry.lastResult), result: entry?.lastResult || null };
    }
    case 'SG_RESCAN': {
      const tabId = msg.tabId;
      if (tabId != null) {
        try { await chrome.tabs.sendMessage(tabId, { type: 'SG_HIDE' }); } catch (_) {}
        chrome.tabs.reload(tabId);
      }
      return { ok: true };
    }
    default:
      return { ok: false, error: 'unknown message type' };
  }
}

// ---------------------------------------------------------------- analysis pipeline

async function maybeAnalyze(tabId) {
  const entry = pending.get(tabId);
  if (!entry || entry.analyzed || !entry.headers || !entry.dom) return;
  entry.analyzed = true;

  const settings = await Storage.getSettings();
  const domain = entry.hostname;

  if (settings.allowlist.includes(domain)) {
    await finish(tabId, entry, { score: 0, band: { key: 'very_low', label: 'Very Low' }, ranked: [], action: 'allow', gate: {} }, [], settings, { forcedAllow: true });
    return;
  }

  const chain = redirectChains.get(tabId) || [];
  const crossDomainHops = countCrossDomainHops(chain);
  const ctx = {
    url: entry.url,
    hostname: entry.hostname,
    protocol: entry.protocol,
    headers: entry.headers,
    redirectChain: { length: chain.length, crossDomainHops },
    dom: entry.dom,
  };

  let findings = Rules.runRules(ctx);

  // Optional backend augmentation (architecture doc §11.3). Best-effort,
  // never blocks the local pipeline, and clearly tagged as external/inference.
  if (settings.backendUrl) {
    try {
      const backendFindings = await queryBackend(settings, ctx);
      if (Array.isArray(backendFindings)) findings = findings.concat(backendFindings);
    } catch (_) { /* offline / misconfigured backend: degrade to local-only */ }
  }

  if (settings.denylist.includes(domain)) {
    findings.push({
      id: 'denylist-' + domain,
      category: 'policy',
      title: 'Domain is on your block list',
      severity: 'critical',
      confidence: 1,
      evidenceQuality: 1,
      evidenceType: 'detected',
      evidence: `"${domain}" is on your personal block list (Settings).`,
      remediation: 'Remove it from your block list if this was added in error.',
    });
  }

  const thresholds = Scoring.SENSITIVITY_THRESHOLDS?.[settings.sensitivity] || undefined;
  const decision = Scoring.decide(findings, { thresholds: {
    warnFloor: (Storage.SENSITIVITY_THRESHOLDS[settings.sensitivity] || Storage.SENSITIVITY_THRESHOLDS.balanced).warnFloor,
    blockFloor: (Storage.SENSITIVITY_THRESHOLDS[settings.sensitivity] || Storage.SENSITIVITY_THRESHOLDS.balanced).blockFloor,
  }});

  await finish(tabId, entry, decision, findings, settings, {});
}

function countCrossDomainHops(chain) {
  let hops = 0;
  let lastHost = null;
  for (const hop of chain) {
    const h = domainOf(hop.to);
    if (lastHost && h && h !== lastHost) hops += 1;
    lastHost = h || lastHost;
  }
  return hops;
}

async function queryBackend(settings, ctx) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 3000);
  try {
    const res = await fetch(`${settings.backendUrl.replace(/\/$/, '')}/v1/scan/quick`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(settings.backendToken ? { Authorization: `Bearer ${settings.backendToken}` } : {}),
      },
      body: JSON.stringify({
        domain: ctx.hostname,
        protocol: ctx.protocol.replace(':', ''),
        // Minimized feature vector only — no raw page content, no cookie values.
        features: {
          has_hsts: !!ctx.headers.hsts,
          csp_present: !!ctx.headers.csp,
          mixed_content_count: (ctx.dom.mixedContentResources || []).length,
          redirect_chain_len: ctx.redirectChain.length,
          redirect_cross_domain_hops: ctx.redirectChain.crossDomainHops,
          third_party_script_count: (ctx.dom.thirdPartyScripts || []).length,
          form_has_password_field: (ctx.dom.forms || []).some((f) => f.hasPassword),
        },
      }),
      signal: controller.signal,
    });
    if (!res.ok) return null;
    const data = await res.json();
    return (data.top_findings || []).map((f) => ({
      id: f.id || `backend-${Math.random().toString(36).slice(2)}`,
      category: f.category || 'backend',
      title: f.title || f.category || 'Backend finding',
      severity: f.severity || 'medium',
      confidence: typeof f.confidence === 'number' ? f.confidence : 0.6,
      evidenceQuality: typeof f.evidence_quality === 'number' ? f.evidence_quality : 0.5,
      evidenceType: f.evidence_quality >= 0.9 ? 'external' : 'inference',
      evidence: f.evidence || 'Reported by connected backend.',
      remediation: f.remediation || '',
      cwe: f.cwe || null,
    }));
  } finally {
    clearTimeout(timeout);
  }
}

async function finish(tabId, entry, decision, findings, settings, flags) {
  const domain = entry.hostname;
  const explanation = XAI.explain(decision, domain);
  entry.lastResult = { decision, explanation, url: entry.url, timestamp: Date.now() };
  pending.set(tabId, entry);

  await setBadge(tabId, decision, flags.forcedAllow);

  await Storage.pushHistory(domain, {
    url: entry.url,
    score: decision.score,
    band: decision.band,
    action: flags.forcedAllow ? 'allow' : decision.action,
    findings: findings.map(({ id, category, title, severity, confidence, evidenceQuality, evidence, evidenceType, remediation, cwe }) =>
      ({ id, category, title, severity, confidence, evidenceQuality, evidence, evidenceType, remediation, cwe })),
    explanation,
  });

  if (flags.forcedAllow || settings.mode !== 'auto') return;

  const bypassed = (allowOnce.get(domain) || 0) > Date.now();
  if (bypassed) return;

  if (decision.action === 'block' && settings.autoBlockCritical) {
    const policyLocked = decision.score >= 90; // very high scores: discourage silent dismissal
    trySend(tabId, { type: 'SG_SHOW_BLOCK', explanation, policyLocked });
  } else if (decision.action === 'warn' || decision.action === 'block') {
    trySend(tabId, { type: 'SG_SHOW_WARN', explanation });
  }
}

function trySend(tabId, message) {
  chrome.tabs.sendMessage(tabId, message, () => void chrome.runtime.lastError);
}

async function setBadge(tabId, decision, forcedAllow) {
  const colors = {
    very_low: '#5a9e6f', low: '#5a9e6f', moderate: '#d9932c', high: '#c0392b', critical: '#8e1f16',
  };
  const key = forcedAllow ? 'very_low' : decision.band.key;
  const text = forcedAllow || decision.score < 15 ? '' : String(decision.score);
  try {
    await chrome.action.setBadgeText({ tabId, text });
    await chrome.action.setBadgeBackgroundColor({ tabId, color: colors[key] || '#5a5a5a' });
  } catch (_) { /* tab may have closed */ }
}

chrome.tabs.onRemoved.addListener((tabId) => {
  pending.delete(tabId);
  redirectChains.delete(tabId);
});

// ---------------------------------------------------------------- declarativeNetRequest (denylist)

async function syncDenylistRules() {
  const settings = await Storage.getSettings();
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing.map((r) => r.id);
  const addRules = settings.denylist.slice(0, 5000).map((domain, i) => ({
    id: i + 1,
    priority: 1,
    action: { type: 'block' },
    condition: { requestDomains: [domain], resourceTypes: ['main_frame'] },
  }));
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
  } catch (err) {
    console.error('SiteGuard: failed to sync denylist rules', err);
  }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[Storage.SG_KEYS.settings]) {
    syncDenylistRules();
  }
});

// ---------------------------------------------------------------- lifecycle

chrome.runtime.onInstalled.addListener(async () => {
  await Storage.ensureInstalled();
  await syncDenylistRules();
});

chrome.runtime.onStartup?.addListener(() => {
  syncDenylistRules();
});
