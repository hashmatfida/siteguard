const els = {
  loading: document.getElementById('loading'),
  content: document.getElementById('content'),
  notHttp: document.getElementById('notHttp'),
  domain: document.getElementById('domain'),
  gauge: document.getElementById('gauge'),
  scoreNum: document.getElementById('scoreNum'),
  bandLabel: document.getElementById('bandLabel'),
  findingsCount: document.getElementById('findingsCount'),
  recommendation: document.getElementById('recommendation'),
  factors: document.getElementById('factors'),
  reportBtn: document.getElementById('reportBtn'),
  rescanBtn: document.getElementById('rescanBtn'),
  fpBtn: document.getElementById('fpBtn'),
  settingsBtn: document.getElementById('settingsBtn'),
  whyLink: document.getElementById('whyLink'),
};

let activeTab = null;
let activeDomain = null;

function showState(name) {
  els.loading.classList.toggle('hidden', name !== 'loading');
  els.content.classList.toggle('hidden', name !== 'content');
  els.notHttp.classList.toggle('hidden', name !== 'notHttp');
}

function bandKey(entry) {
  return entry.band?.key || 'low';
}

function render(entry) {
  showState('content');
  els.domain.textContent = activeDomain;

  const key = bandKey(entry);
  els.gauge.className = 'gauge ' + (key === 'very_low' ? 'low' : key);
  els.scoreNum.textContent = entry.score;
  els.bandLabel.textContent = (entry.band?.label || '—') + ' risk';

  const count = (entry.findings || []).length;
  els.findingsCount.textContent = `${count} finding${count === 1 ? '' : 's'}`;

  const explanation = entry.explanation || {};
  els.recommendation.textContent = explanation.recommendation || 'No summary available.';

  els.factors.innerHTML = (explanation.factors || []).slice(0, 3).map((f) => `
    <li>
      <span class="tag">${f.contributionLabel}</span>
      <span class="tag">${f.evidenceTypeLabel}</span>
      <div class="title">${escapeHtml(f.title)}</div>
      <div class="ev">${escapeHtml(f.evidence)}</div>
    </li>
  `).join('') || '<li class="ev">No notable findings.</li>';
}

function escapeHtml(s) {
  return (s || '').replace(/[&<>"']/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}

async function loadLatest() {
  const history = await SiteGuardStorage.getHistory(activeDomain);
  if (history.length === 0) {
    showState('loading');
    return false;
  }
  render(history[0]);
  return true;
}

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTab = tab;
  if (!tab || !/^https?:\/\//i.test(tab.url || '')) {
    showState('notHttp');
    return;
  }
  activeDomain = new URL(tab.url).hostname;
  showState('loading');

  const found = await loadLatest();
  if (!found) {
    // Poll briefly in case the background analysis is still in flight.
    const interval = setInterval(async () => {
      if (await loadLatest()) clearInterval(interval);
    }, 500);
    setTimeout(() => clearInterval(interval), 8000);
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const key = SiteGuardStorage.SG_KEYS.history(activeDomain);
    if (changes[key]) loadLatest();
  });
}

els.reportBtn.addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL(`report/report.html?domain=${encodeURIComponent(activeDomain)}`) });
});
els.rescanBtn.addEventListener('click', () => {
  if (activeTab) chrome.runtime.sendMessage({ type: 'SG_RESCAN', tabId: activeTab.id });
  showState('loading');
  window.close();
});
els.fpBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'SG_FALSE_POSITIVE', domain: activeDomain, source: 'popup' });
  els.fpBtn.textContent = 'Reported — thank you';
  els.fpBtn.disabled = true;
});
els.settingsBtn.addEventListener('click', () => chrome.runtime.openOptionsPage());
els.whyLink.addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: chrome.runtime.getURL('report/report.html?domain=' + encodeURIComponent(activeDomain || '') + '&explainer=1') });
});

init();
