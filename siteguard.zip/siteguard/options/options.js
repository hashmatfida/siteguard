const els = {
  mode: document.getElementById('mode'),
  sensitivity: document.getElementById('sensitivity'),
  autoBlockCritical: document.getElementById('autoBlockCritical'),
  retentionDays: document.getElementById('retentionDays'),
  backendUrl: document.getElementById('backendUrl'),
  backendToken: document.getElementById('backendToken'),
  allowInput: document.getElementById('allowInput'),
  allowAdd: document.getElementById('allowAdd'),
  allowList: document.getElementById('allowList'),
  denyInput: document.getElementById('denyInput'),
  denyAdd: document.getElementById('denyAdd'),
  denyList: document.getElementById('denyList'),
  clearHistory: document.getElementById('clearHistory'),
  savedNote: document.getElementById('savedNote'),
};

let settings = null;

function normalizeDomain(v) {
  return (v || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
}

function renderChips(listEl, items, listName) {
  listEl.innerHTML = items.map((d) => `
    <li>${escapeHtml(d)}<button data-domain="${escapeHtml(d)}" data-list="${listName}">✕</button></li>
  `).join('') || '<li style="color:#999;background:none;border:none;">none</li>';
}

function escapeHtml(s) {
  return (s || '').replace(/[&<>"']/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}

async function load() {
  settings = await SiteGuardStorage.getSettings();
  els.mode.value = settings.mode;
  els.sensitivity.value = settings.sensitivity;
  els.autoBlockCritical.checked = settings.autoBlockCritical;
  els.retentionDays.value = String(settings.retentionDays);
  els.backendUrl.value = settings.backendUrl || '';
  els.backendToken.value = settings.backendToken || '';
  renderChips(els.allowList, settings.allowlist, 'allowlist');
  renderChips(els.denyList, settings.denylist, 'denylist');
}

async function save(partial) {
  settings = await SiteGuardStorage.saveSettings(partial);
  els.savedNote.classList.remove('hidden');
  setTimeout(() => els.savedNote.classList.add('hidden'), 1400);
}

els.mode.addEventListener('change', () => save({ mode: els.mode.value }));
els.sensitivity.addEventListener('change', () => save({ sensitivity: els.sensitivity.value }));
els.autoBlockCritical.addEventListener('change', () => save({ autoBlockCritical: els.autoBlockCritical.checked }));
els.retentionDays.addEventListener('change', () => save({ retentionDays: Number(els.retentionDays.value) }));
els.backendUrl.addEventListener('change', () => save({ backendUrl: els.backendUrl.value.trim() }));
els.backendToken.addEventListener('change', () => save({ backendToken: els.backendToken.value.trim() }));

els.allowAdd.addEventListener('click', async () => {
  const d = normalizeDomain(els.allowInput.value);
  if (!d) return;
  await SiteGuardStorage.addToList(d, 'allowlist');
  els.allowInput.value = '';
  await load();
});
els.denyAdd.addEventListener('click', async () => {
  const d = normalizeDomain(els.denyInput.value);
  if (!d) return;
  await SiteGuardStorage.addToList(d, 'denylist');
  els.denyInput.value = '';
  await load();
});

document.addEventListener('click', async (e) => {
  const btn = e.target.closest('button[data-domain]');
  if (!btn) return;
  await SiteGuardStorage.removeFromList(btn.dataset.domain, btn.dataset.list);
  await load();
});

els.clearHistory.addEventListener('click', async () => {
  if (!confirm('Delete all locally stored scan history? This cannot be undone.')) return;
  await SiteGuardStorage.clearHistory();
  alert('Scan history cleared.');
});

load();
