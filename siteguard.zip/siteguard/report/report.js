function escapeHtml(s) {
  return (s || '').replace(/[&<>"']/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}
function fmtTime(ts) {
  return new Date(ts).toLocaleString();
}

const SEV_ORDER = ['critical', 'high', 'medium', 'low', 'info'];
const SEV_LABEL = { critical: 'Critical', high: 'High', medium: 'Medium', low: 'Low', info: 'Informational' };

async function init() {
  const params = new URLSearchParams(location.search);
  const domain = params.get('domain') || '';
  document.getElementById('domain').textContent = domain || '(unknown domain)';

  const history = await SiteGuardStorage.getHistory(domain);
  if (history.length === 0) {
    document.getElementById('empty').classList.remove('hidden');
    return;
  }
  document.getElementById('main').classList.remove('hidden');

  const latest = history[0];
  renderSummary(latest);
  renderSeverity(latest.findings || []);
  renderFindings(latest.findings || []);
  renderHistory(history);

  if (params.get('explainer') === '1') {
    document.getElementById('howitworks').scrollIntoView({ behavior: 'smooth' });
  }
}

function renderSummary(entry) {
  const key = entry.band?.key === 'very_low' ? 'low' : (entry.band?.key || 'low');
  const gauge = document.getElementById('gauge');
  gauge.className = 'gauge ' + key;
  document.getElementById('scoreNum').textContent = entry.score;
  document.getElementById('bandLabel').textContent = (entry.band?.label || '—') + ' risk';
  document.getElementById('timestamp').textContent = fmtTime(entry.timestamp);
  const count = (entry.findings || []).length;
  document.getElementById('findingsCount').textContent = `${count} finding${count === 1 ? '' : 's'} · action: ${entry.action}`;
  document.getElementById('recommendation').textContent = entry.explanation?.recommendation || '';
}

function renderSeverity(findings) {
  const counts = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
  for (const f of findings) counts[f.severity] = (counts[f.severity] || 0) + 1;
  const max = Math.max(1, ...Object.values(counts));
  const el = document.getElementById('severityBars');
  el.innerHTML = SEV_ORDER.map((s) => `
    <div class="sev-row">
      <span>${SEV_LABEL[s]}</span>
      <div class="sev-track"><div class="sev-fill ${s}" style="width:${(counts[s] / max) * 100}%"></div></div>
      <span>${counts[s]}</span>
    </div>
  `).join('');
}

function renderFindings(findings) {
  const el = document.getElementById('findingsList');
  if (findings.length === 0) {
    el.innerHTML = '<p class="note">No findings on this scan — nothing to show.</p>';
    return;
  }
  const sorted = [...findings].sort((a, b) => SEV_ORDER.indexOf(a.severity) - SEV_ORDER.indexOf(b.severity));
  el.innerHTML = sorted.map((f) => `
    <div class="finding-card">
      <div class="finding-head">
        <span class="sev-badge ${f.severity}">${SEV_LABEL[f.severity] || f.severity}</span>
        <span class="ev-badge">${labelForType(f.evidenceType)}</span>
        <span class="finding-title">${escapeHtml(f.title)}</span>
      </div>
      <div class="finding-evidence">${escapeHtml(f.evidence)}</div>
      ${f.remediation ? `<div class="finding-remediation">Remediation: ${escapeHtml(f.remediation)}</div>` : ''}
      <div class="finding-meta">
        <span>Category: ${escapeHtml(f.category)}</span>
        <span>Confidence: ${Math.round((f.confidence || 0) * 100)}%</span>
        <span>Evidence quality: ${Math.round((f.evidenceQuality || 0) * 100)}%</span>
        ${f.cwe ? `<span>${escapeHtml(f.cwe)}</span>` : ''}
      </div>
    </div>
  `).join('');
}

function labelForType(t) {
  return { detected: 'Detected fact', inference: 'Heuristic inference', external: 'External evidence' }[t] || 'Detected fact';
}

function renderHistory(history) {
  const body = document.getElementById('historyBody');
  body.innerHTML = history.map((e) => `
    <tr>
      <td>${fmtTime(e.timestamp)}</td>
      <td>${e.score}</td>
      <td>${e.band?.label || ''}</td>
      <td>${e.action}</td>
      <td>${(e.findings || []).length}</td>
    </tr>
  `).join('');
}

init();
