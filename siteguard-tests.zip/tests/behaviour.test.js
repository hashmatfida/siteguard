const test = require('node:test');
const assert = require('node:assert/strict');
const { createWorker, GOOD_HEADERS, CLEAN_SIGNALS } = require('./harness');

const URL1 = 'https://example.com/';

async function loadPage(w, tabId, url, reqId, headers = GOOD_HEADERS, signals = CLEAN_SIGNALS) {
  w.beforeRequest(tabId, url, reqId);
  w.headersReceived(tabId, url, reqId, headers);
  await w.settle();
  const r = await w.message({ type: 'SG_SIGNALS', url, signals }, w.fromContent(tabId, url));
  await w.settle();
  return r;
}

test('clean HTTPS page scores low, sets history, no overlay, never touches alarms/webNavigation', async () => {
  const w = createWorker();
  await w.install();
  await loadPage(w, 1, URL1, 'r1');
  const hist = await w.store.getHistory('example.com');
  assert.equal(hist.length, 1);
  assert.ok(hist[0].score < 15, 'score ' + hist[0].score);
  assert.equal(w.sent.filter((s) => /SG_SHOW/.test(s.msg.type)).length, 0);
  assert.equal(hist[0].url, 'https://example.com/');
});

test('history URL never contains the query string or fragment', async () => {
  const w = createWorker();
  await loadPage(w, 1, 'https://example.com/reset?token=SECRET123#frag', 'r1');
  const hist = await w.store.getHistory('example.com');
  assert.equal(hist[0].url, 'https://example.com/reset');
  assert.ok(!JSON.stringify(w.shared.local).includes('SECRET123'));
});

test('BUG FIX: previous page\'s DOM signals are never scored with the next page\'s headers', async () => {
  const w = createWorker();
  const loginSignals = { ...CLEAN_SIGNALS, forms: [{ hasPassword: true, actionIsCrossOrigin: false, actionIsHttp: true, actionOrigin: 'http://x' }], isLoginOrPaymentContext: true };
  await loadPage(w, 1, 'https://a.example.org/', 'r1', GOOD_HEADERS, loginSignals);
  const a = await w.store.getHistory('a.example.org');
  assert.ok(a[0].findings.some((f) => /Password form submits over HTTP/.test(f.title)));

  // Navigate same tab: headers arrive, but NO signals from the new page yet.
  w.beforeRequest(1, 'https://b.example.net/', 'r2');
  w.headersReceived(1, 'https://b.example.net/', 'r2', GOOD_HEADERS);
  await w.settle();
  assert.equal((await w.store.getHistory('b.example.net')).length, 0, 'must wait for the new page\'s own signals');

  await w.message({ type: 'SG_SIGNALS', url: 'https://b.example.net/', signals: CLEAN_SIGNALS }, w.fromContent(1, 'https://b.example.net/'));
  await w.settle();
  const b = await w.store.getHistory('b.example.net');
  assert.equal(b.length, 1);
  assert.ok(!b[0].findings.some((f) => /Password form/.test(f.title)), 'no leakage of page A findings into page B');
});

test('stale signals from a different origin are ignored', async () => {
  const w = createWorker();
  w.beforeRequest(1, 'https://new.example.net/', 'r9');
  w.headersReceived(1, 'https://new.example.net/', 'r9', GOOD_HEADERS);
  await w.settle();
  const r = await w.message({ type: 'SG_SIGNALS', url: 'https://old.example.org/', signals: CLEAN_SIGNALS }, w.fromContent(1, 'https://old.example.org/'));
  assert.equal(r.stale, true);
  assert.equal((await w.store.getHistory('new.example.net')).length, 0);
});

test('redirect chain tracked via webRequest only (3 cross-domain hops => high finding)', async () => {
  const w = createWorker();
  const hops = ['https://a.com/', 'https://b.net/', 'https://c.org/', 'https://d.io/'];
  w.beforeRequest(2, hops[0], 'rr');
  for (let i = 0; i < 3; i++) {
    w.headersReceived(2, hops[i], 'rr', [['Location', hops[i + 1]]], 302);
    w.beforeRedirect(2, hops[i], hops[i + 1], 'rr');
    w.beforeRequest(2, hops[i + 1], 'rr'); // same requestId continues the chain
  }
  w.headersReceived(2, hops[3], 'rr', GOOD_HEADERS, 200);
  await w.settle();
  await w.message({ type: 'SG_SIGNALS', url: hops[3], signals: CLEAN_SIGNALS }, w.fromContent(2, hops[3]));
  await w.settle();
  const h = await w.store.getHistory('d.io');
  assert.ok(h[0].findings.some((f) => /Long cross-domain redirect chain/.test(f.title)), JSON.stringify(h[0].findings.map((f) => f.title)));
});

test('redirect chain still works if every hop gets a NEW requestId (fallback on URL continuity)', async () => {
  const w = createWorker();
  const hops = ['https://a.com/', 'https://b.net/', 'https://c.org/', 'https://d.io/'];
  w.beforeRequest(3, hops[0], 'x0');
  for (let i = 0; i < 3; i++) {
    w.beforeRedirect(3, hops[i], hops[i + 1], 'x' + i);
    w.beforeRequest(3, hops[i + 1], 'x' + (i + 1));
  }
  w.headersReceived(3, hops[3], 'x3', GOOD_HEADERS, 200);
  await w.settle();
  await w.message({ type: 'SG_SIGNALS', url: hops[3], signals: CLEAN_SIGNALS }, w.fromContent(3, hops[3]));
  await w.settle();
  const h = await w.store.getHistory('d.io');
  assert.ok(h[0].findings.some((f) => /redirect/i.test(f.title)));
});

test('www/http->https redirects on the same registrable domain are not "cross-domain"', async () => {
  const w = createWorker();
  w.beforeRequest(4, 'http://example.com/', 'q');
  w.headersReceived(4, 'http://example.com/', 'q', [['Location', 'https://www.example.com/']], 301);
  w.beforeRedirect(4, 'http://example.com/', 'https://www.example.com/', 'q');
  w.beforeRequest(4, 'https://www.example.com/', 'q');
  w.headersReceived(4, 'https://www.example.com/', 'q', GOOD_HEADERS);
  await w.settle();
  await w.message({ type: 'SG_SIGNALS', url: 'https://www.example.com/', signals: CLEAN_SIGNALS }, w.fromContent(4, 'https://www.example.com/'));
  await w.settle();
  const h = await w.store.getHistory('www.example.com');
  assert.ok(!h[0].findings.some((f) => /redirect/i.test(f.title)));
});

test('SERVICE-WORKER RESTART: state survives in storage.session; analysis completes in a fresh worker', async () => {
  const shared = {};
  const w1 = createWorker(shared);
  w1.beforeRequest(5, URL1, 'rs');
  w1.headersReceived(5, URL1, 'rs', GOOD_HEADERS);
  await w1.settle();
  const w2 = createWorker(shared); // worker was killed and restarted: all in-memory state is gone
  await w2.message({ type: 'SG_SIGNALS', url: URL1, signals: CLEAN_SIGNALS }, w2.fromContent(5, URL1));
  await w2.settle();
  assert.equal((await w2.store.getHistory('example.com')).length, 1);
  const st = await w2.message({ type: 'SG_GET_TAB_STATE', tabId: 5 }, w2.fromPopup());
  assert.equal(st.ready, true);
});

test('SERVICE-WORKER RESTART: "continue anyway" bypass survives', async () => {
  const shared = {};
  const w1 = createWorker(shared);
  await loadPage(w1, 6, URL1, 'ra');
  await w1.message({ type: 'SG_ALLOW_ONCE' }, w1.fromContent(6, URL1));
  const w2 = createWorker(shared);
  assert.equal(await w2.store.isAllowedOnce('example.com'), true);
});

test('block overlay shown for a clearly bad HTTP login page (auto mode)', async () => {
  const w = createWorker();
  const bad = { ...CLEAN_SIGNALS, forms: [{ hasPassword: true, actionIsCrossOrigin: false, actionIsHttp: true, actionOrigin: 'http://bad.test' }], isLoginOrPaymentContext: true, mixedContentResources: [], sensitiveLinks: [{ href: 'http://bad.test/.env' }], inlineScripts: [{ length: 900, obfuscation: { score: 6, reasons: ['3 use(s) of eval()'] } }] };
  await loadPage(w, 7, 'http://bad.test/login', 'rb', [['Set-Cookie', 'session=1']], bad);
  const shown = w.sent.filter((s) => /SG_SHOW/.test(s.msg.type));
  assert.equal(shown.length, 1);
  assert.equal(shown[0].msg.type, 'SG_SHOW_BLOCK');
  assert.ok(Number(w.badges[7]) >= 60);
});

test('"continue anyway" suppresses the overlay on the next scan of that domain', async () => {
  const w = createWorker();
  await w.store.setAllowOnce('bad.test', 60000);
  const bad = { ...CLEAN_SIGNALS, forms: [{ hasPassword: true, actionIsCrossOrigin: false, actionIsHttp: true, actionOrigin: 'http://bad.test' }], isLoginOrPaymentContext: true };
  await loadPage(w, 8, 'http://bad.test/login', 'rc', [], bad);
  assert.equal(w.sent.filter((s) => /SG_SHOW/.test(s.msg.type)).length, 0);
});

test('SG_ALLOW_ONCE uses the hostname SiteGuard captured, not a caller-supplied one', async () => {
  const w = createWorker();
  await loadPage(w, 9, URL1, 'rd');
  await w.message({ type: 'SG_ALLOW_ONCE', domain: 'victim.com' }, w.fromContent(9, URL1));
  assert.equal(await w.store.isAllowedOnce('victim.com'), false);
  assert.equal(await w.store.isAllowedOnce('example.com'), true);
});

test('popup-only messages are rejected from content scripts', async () => {
  const w = createWorker();
  const r = await w.message({ type: 'SG_RESCAN', tabId: 1 }, w.fromContent(1, URL1));
  assert.equal(r.ok, false);
  assert.equal(w.reloaded.length, 0);
});

test('MANUAL mode: nothing is analysed/stored/badged until the popup asks', async () => {
  const w = createWorker();
  await w.store.saveSettings({ mode: 'manual' });
  await loadPage(w, 10, URL1, 'rm');
  assert.equal((await w.store.getHistory('example.com')).length, 0);
  assert.equal(w.sent.filter((s) => /SG_SHOW/.test(s.msg.type)).length, 0);
  const r = await w.message({ type: 'SG_SCAN_NOW', tabId: 10 }, w.fromPopup());
  assert.equal(r.status, 'ready');
  assert.equal((await w.store.getHistory('example.com')).length, 1);
  assert.equal(w.sent.filter((s) => /SG_SHOW/.test(s.msg.type)).length, 0, 'manual mode never injects overlays');
});

test('MANUAL mode: no headers captured -> popup is told to reload', async () => {
  const w = createWorker();
  await w.store.saveSettings({ mode: 'manual' });
  const r = await w.message({ type: 'SG_SCAN_NOW', tabId: 99 }, w.fromPopup());
  assert.equal(r.status, 'needs_reload');
});

test('RESCAN: reloads the tab and the next navigation is scanned even in manual mode', async () => {
  const w = createWorker();
  await w.store.saveSettings({ mode: 'manual' });
  await w.message({ type: 'SG_RESCAN', tabId: 11 }, w.fromPopup());
  assert.deepEqual(w.reloaded, [11]);
  await loadPage(w, 11, URL1, 'rn');
  assert.equal((await w.store.getHistory('example.com')).length, 1);
});

test('allow-listed domain (and its subdomains) is not scanned and is labelled honestly', async () => {
  const w = createWorker();
  await w.store.saveSettings({ allowlist: ['example.com'] });
  await loadPage(w, 12, 'https://www.example.com/', 're', []);
  const h = await w.store.getHistory('www.example.com');
  assert.equal(h[0].forcedAllow, true);
  assert.equal(h[0].findings.length, 0);
  assert.match(h[0].explanation.recommendation, /allow list/);
});

test('stale badge is cleared when a tab starts loading', async () => {
  const w = createWorker();
  w.badges[13] = '77';
  w.fire(w.chrome.tabs.onUpdated, 13, { status: 'loading' });
  await w.settle();
  assert.equal(w.badges[13], '');
});

test('closed tab leaves no session state behind', async () => {
  const w = createWorker();
  await loadPage(w, 14, URL1, 'rx');
  assert.ok(w.shared.session['sg:tab:14']);
  w.fire(w.chrome.tabs.onRemoved, 14);
  await w.settle();
  assert.equal(w.shared.session['sg:tab:14'], undefined);
});

test('raw headers/DOM are dropped from session state after the verdict; cookie VALUES never stored', async () => {
  const w = createWorker();
  await loadPage(w, 15, URL1, 'ry', [...GOOD_HEADERS, ['Set-Cookie', 'sid=SUPERSECRETVALUE; Secure; HttpOnly; SameSite=Lax']]);
  const dump = JSON.stringify(w.shared);
  assert.ok(!dump.includes('SUPERSECRETVALUE'));
  const rec = w.shared.session['sg:tab:15'];
  assert.equal(rec.headers, null);
  assert.equal(rec.dom, null);
});

// ---------------------------------------------------------------- retention (replaces the unused alarms permission)

test('RETENTION: expired history for sites you never revisit is deleted without any alarm', async () => {
  const w = createWorker();
  await w.store.saveSettings({ retentionDays: 30 });
  await w.settle(); // let the "retention setting changed" auto-prune finish before seeding data
  const old = Date.now() - 100 * 86400000;
  const fresh = Date.now() - 1 * 86400000;
  w.shared.local['sg:history:oldsite.com'] = [{ timestamp: old, score: 1 }];
  w.shared.local['sg:history:mixed.com'] = [{ timestamp: fresh, score: 2 }, { timestamp: old, score: 3 }];
  w.shared.local['sg:history:index'] = ['oldsite.com', 'mixed.com'];
  const res = await w.store.pruneExpiredHistory();
  assert.equal(res.removedDomains, 1);
  assert.equal(w.shared.local['sg:history:oldsite.com'], undefined);
  assert.equal(w.shared.local['sg:history:mixed.com'].length, 1);
  assert.deepEqual(w.shared.local['sg:history:index'], ['mixed.com']);
});

test('RETENTION: runs on browser startup, and when the retention setting is shortened', async () => {
  const w = createWorker();
  const t = Date.now() - 20 * 86400000;
  w.shared.local['sg:history:a.com'] = [{ timestamp: t, score: 1 }];
  w.shared.local['sg:history:index'] = ['a.com'];
  await w.store.saveSettings({ retentionDays: 30 });
  await w.store.saveSettings({ retentionDays: 7 }); // triggers storage.onChanged -> prune
  await w.settle();
  assert.equal(w.shared.local['sg:history:a.com'], undefined);

  w.shared.local['sg:history:b.com'] = [{ timestamp: Date.now() - 40 * 86400000, score: 1 }];
  w.shared.local['sg:history:index'] = ['b.com'];
  delete w.shared.local['sg:lastPrune'];
  for (const fn of w.L(w.chrome.runtime.onStartup)) fn();
  await w.settle();
  assert.equal(w.shared.local['sg:history:b.com'], undefined);
});

test('RETENTION: a scan prunes other domains at most once a day', async () => {
  const w = createWorker();
  w.shared.local['sg:history:stale.com'] = [{ timestamp: Date.now() - 400 * 86400000, score: 1 }];
  w.shared.local['sg:history:index'] = ['stale.com'];
  await loadPage(w, 16, URL1, 'rp');
  await w.settle();
  assert.equal(w.shared.local['sg:history:stale.com'], undefined);
});

test('history is capped per domain and domain count is bounded (storage quota safety)', async () => {
  const w = createWorker();
  for (let i = 0; i < 40; i++) await w.store.pushHistory('busy.com', { score: i, findings: [] });
  assert.ok((await w.store.getHistory('busy.com')).length <= 15);
  const w2 = createWorker();
  for (let i = 0; i < 310; i++) await w2.store.pushHistory(`d${i}.com`, { score: 1, findings: [] });
  const idx = await w2.store.getAllDomainsWithHistory();
  assert.equal(idx.length, 300);
  assert.equal(w2.shared.local['sg:history:d0.com'], undefined, 'oldest domain evicted');
});

test('upgrade from v1.0: stored URLs with query strings are scrubbed', async () => {
  const w = createWorker();
  w.shared.local['sg:history:x.com'] = [{ timestamp: Date.now(), url: 'https://x.com/p?token=abc#h', score: 1 }];
  w.shared.local['sg:history:index'] = ['x.com'];
  await w.install('update');
  assert.equal(w.shared.local['sg:history:x.com'][0].url, 'https://x.com/p');
});

// ---------------------------------------------------------------- declarativeNetRequest

test('DNR: block list syncs rules; invalid entries are dropped at validation', async () => {
  const w = createWorker();
  await w.store.saveSettings({ denylist: ['Evil.com', 'https://bad.example:8080/x', 'not a domain', 'evil.com'] });
  await w.settle();
  const domains = w.shared.dnr.map((r) => r.condition.requestDomains[0]);
  assert.deepEqual(domains.sort(), ['bad.example', 'evil.com']);
});

test('DNR: one rejected rule cannot disable the rest (falls back to per-rule adds)', async () => {
  const w = createWorker({}, { dnrReject: (rule) => { if (rule.condition.requestDomains[0] === 'bad.com' && !rule.__single) { /* only reject in batch mode */ } } });
  // Simulate: batch containing bad.com fails, individual adds for good ones succeed.
  let batchCalls = 0;
  const orig = w.chrome.declarativeNetRequest.updateDynamicRules;
  w.chrome.declarativeNetRequest.updateDynamicRules = async (arg) => {
    if ((arg.addRules || []).length > 1) { batchCalls++; throw new Error('Rule with id 2 has an invalid domain'); }
    if ((arg.addRules || []).length === 1 && arg.addRules[0].condition.requestDomains[0] === 'bad.com') throw new Error('invalid');
    return orig(arg);
  };
  await w.store.saveSettings({ denylist: ['good1.com', 'bad.com', 'good2.com'] });
  await w.settle();
  assert.ok(batchCalls >= 1);
  const domains = w.shared.dnr.map((r) => r.condition.requestDomains[0]).sort();
  assert.deepEqual(domains, ['good1.com', 'good2.com']);
});

// ---------------------------------------------------------------- optional backend: consent, security, error reporting

const bad = { ...CLEAN_SIGNALS, forms: [{ hasPassword: true, actionIsCrossOrigin: false, actionIsHttp: false, actionOrigin: null }] };

test('BACKEND: never contacted without explicit consent, even if a URL is saved', async () => {
  const w = createWorker({}, { fetchImpl: async () => ({ ok: true, text: async () => '{"top_findings":[]}' }) });
  await w.store.saveSettings({ backendUrl: 'https://api.example.com', backendConsent: false });
  await loadPage(w, 20, URL1, 'b1');
  assert.equal(w.fetchCalls.length, 0);
});

test('BACKEND: consent is dropped automatically when there is no URL', async () => {
  const w = createWorker();
  const s = await w.store.saveSettings({ backendUrl: '', backendConsent: true });
  assert.equal(s.backendConsent, false);
});

test('BACKEND: with consent — HTTPS POST, minimal body, no URL/query/cookies/page content, bearer in header only', async () => {
  const w = createWorker({}, { fetchImpl: async () => ({ ok: true, text: async () => JSON.stringify({ top_findings: [{ title: 'X', severity: 'low' }] }) }) });
  await w.store.saveSettings({ backendUrl: 'https://api.example.com/', backendConsent: true, backendToken: 'tok123' });
  await loadPage(w, 21, 'https://example.com/secret/path?token=Q', 'b2', [...GOOD_HEADERS, ['Set-Cookie', 'sid=COOKIEVALUE; Secure']], bad);
  assert.equal(w.fetchCalls.length, 1);
  const { url, init } = w.fetchCalls[0];
  assert.equal(url, 'https://api.example.com/v1/scan/quick');
  assert.equal(init.method, 'POST');
  assert.equal(init.credentials, 'omit');
  assert.equal(init.redirect, 'error');
  assert.equal(init.headers.Authorization, 'Bearer tok123');
  assert.ok(!url.includes('?'), 'no data in the query string');
  const body = JSON.parse(init.body);
  assert.deepEqual(Object.keys(body).sort(), ['domain', 'features', 'protocol']);
  const raw = init.body;
  for (const forbidden of ['secret/path', 'token=Q', 'COOKIEVALUE', 'tok123']) assert.ok(!raw.includes(forbidden), forbidden);
  const h = await w.store.getHistory('example.com');
  assert.equal(h[0].backend, 'ok');
});

test('BACKEND: private/internal hosts are never sent', async () => {
  const w = createWorker({}, { fetchImpl: async () => ({ ok: true, text: async () => '{"top_findings":[]}' }) });
  await w.store.saveSettings({ backendUrl: 'https://api.example.com', backendConsent: true });
  for (const [i, u] of ['http://localhost:3000/', 'https://intranet.corp/', 'http://192.168.1.5/', 'https://nas.local/'].entries()) {
    await loadPage(w, 30 + i, u, 'p' + i);
  }
  assert.equal(w.fetchCalls.length, 0);
});

test('BACKEND: plain http:// backend (non-localhost) is rejected at validation', async () => {
  const w = createWorker();
  assert.equal(w.store.normalizeBackendUrl('http://api.example.com').ok, false);
  assert.equal(w.store.normalizeBackendUrl('https://user:pw@api.example.com').ok, false);
  assert.equal(w.store.normalizeBackendUrl('http://localhost:8080').ok, true);
  assert.equal(w.store.normalizeBackendUrl('https://api.example.com/base/?x=1#y').url, 'https://api.example.com/base');
});

test('BACKEND: untrusted response is validated/clamped (bad severity, HTML in strings, huge numbers)', async () => {
  const evil = { top_findings: [
    { id: '<img onerror=1>', category: '<script>', title: '<b>t</b>'.repeat(100), severity: '"><svg onload=1>', confidence: 99, evidence_quality: -5, cwe: 'javascript:1', evidence: 'e'.repeat(5000) },
    'not an object', null,
  ] };
  const w = createWorker({}, { fetchImpl: async () => ({ ok: true, text: async () => JSON.stringify(evil) }) });
  await w.store.saveSettings({ backendUrl: 'https://api.example.com', backendConsent: true });
  await loadPage(w, 40, URL1, 'e1');
  const h = await w.store.getHistory('example.com');
  const f = h[0].findings.find((x) => x.id.startsWith('backend-'));
  assert.ok(f);
  assert.equal(f.severity, 'medium');
  assert.equal(f.cwe, null);
  assert.ok(f.confidence <= 1 && f.evidenceQuality >= 0);
  assert.ok(f.evidence.length <= 300 && f.title.length <= 160);
  assert.ok(!/[<>]/.test(f.category + f.id));
});

test('BACKEND: failure is reported to the user (status "unavailable") and local scan still completes', async () => {
  const w = createWorker({}, { fetchImpl: async () => { throw new Error('network down'); } });
  await w.store.saveSettings({ backendUrl: 'https://api.example.com', backendConsent: true });
  await loadPage(w, 41, URL1, 'e2');
  const h = await w.store.getHistory('example.com');
  assert.equal(h.length, 1);
  assert.equal(h[0].backend, 'unavailable');
  const w2 = createWorker({}, { fetchImpl: async () => ({ ok: false, status: 500 }) });
  await w2.store.saveSettings({ backendUrl: 'https://api.example.com', backendConsent: true });
  await loadPage(w2, 42, URL1, 'e3');
  assert.equal((await w2.store.getHistory('example.com'))[0].backend, 'unavailable');
});
