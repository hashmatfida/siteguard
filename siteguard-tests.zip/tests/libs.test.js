const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const SG = process.env.SG_ROOT ? path.resolve(process.env.SG_ROOT) : path.resolve(__dirname, '../siteguard');
const H = require(path.join(SG, 'lib/heuristics.js'));
const Rules = require(path.join(SG, 'lib/rules.js'));
const Scoring = require(path.join(SG, 'lib/scoring.js'));

// storage.js needs a chrome object only when its async functions run; pure validators work without it
global.chrome = { storage: { local: {}, session: {} } };
const S = require(path.join(SG, 'lib/storage.js'));

test('brandLookalike: catches real impersonation patterns', () => {
  assert.equal(H.brandLookalike('paypa1.com')?.kind, 'confusable');
  assert.equal(H.brandLookalike('rnicrosoft.com')?.kind, 'confusable');
  assert.equal(H.brandLookalike('gooogle.com')?.kind, 'typo');
  assert.equal(H.brandLookalike('githab.com')?.kind, 'typo');
  assert.equal(H.brandLookalike('paypal-secure-login.com')?.kind, 'embedded');
  assert.equal(H.brandLookalike('amaz0n.com')?.kind, 'confusable');
  assert.equal(H.brandLookalike('app1e.com')?.kind, 'confusable', 'short brands are still caught via look-alike characters');
  assert.equal(H.brandLookalike('chase-secure.com')?.kind, 'embedded');
  assert.equal(H.brandLookalike('microsft.com')?.kind, 'typo');
});

test('brandLookalike: no false positives on legitimate / unrelated domains (v1.0 had several)', () => {
  for (const d of ['google.com', 'accounts.google.com', 'mail.google.com', 'google.co.uk', 'amazon.de', 'paypal.me',
    'love.com', 'line.com', 'five.com', 'chose.com', 'apply.com', 'adobo.com', 'bbc.co.uk', 'example.com', 'wikipedia.org', 'apple.co.uk',
    'login.microsoft.com', 'github.io', '192.168.0.1', 'localhost']) {
    assert.equal(H.brandLookalike(d), null, d);
  }
});

test('rootDomain / subdomainCount handle multi-part suffixes', () => {
  assert.equal(H.rootDomain('www.bbc.co.uk'), 'bbc.co.uk');
  assert.equal(H.rootDomain('a.b.example.com'), 'example.com');
  assert.equal(H.subdomainCount('www.bbc.co.uk'), 1);
  assert.equal(H.subdomainCount('a.b.c.d.example.com'), 4);
  assert.equal(H.subdomainCount('10.0.0.1'), 0);
});

test('hostMatches: domain and subdomains only, not suffix tricks', () => {
  assert.ok(H.hostMatches('www.example.com', 'example.com'));
  assert.ok(H.hostMatches('example.com', 'example.com'));
  assert.ok(!H.hostMatches('evilexample.com', 'example.com'));
  assert.ok(!H.hostMatches('example.com.evil.net', 'example.com'));
});

test('isPrivateHost', () => {
  for (const h of ['localhost', 'intranet', 'nas.local', '10.1.2.3', '172.20.0.1', '192.168.1.1', '127.0.0.1', '169.254.1.1', '[::1]', 'fd00::1', 'router.lan']) assert.ok(H.isPrivateHost(h), h);
  for (const h of ['example.com', '8.8.8.8', '172.32.0.1', '1.1.1.1']) assert.ok(!H.isPrivateHost(h), h);
});

test('analyzeCsp: flags real script weaknesses, ignores harmless wildcards', () => {
  assert.equal(H.analyzeCsp("default-src 'self'; img-src * data:; connect-src *").length, 0);
  assert.equal(H.analyzeCsp("script-src 'self' 'nonce-abc' 'unsafe-inline'").length, 0, "unsafe-inline is neutralised by a nonce");
  assert.equal(H.analyzeCsp("script-src 'strict-dynamic' 'nonce-x' https:").length, 0);
  assert.ok(H.analyzeCsp("script-src 'self' 'unsafe-inline'").length > 0);
  assert.ok(H.analyzeCsp("script-src 'self' 'unsafe-eval'").length > 0);
  assert.ok(H.analyzeCsp("default-src *").length > 0);
  assert.ok(H.analyzeCsp("img-src 'self'").length > 0, 'no script control at all');
  assert.equal(H.analyzeCsp("script-src 'unsafe-inline', script-src 'self'").length, 0, 'one strict policy among several is enforced');
});

test('session-cookie classification: CSRF cookies are exempt from the HttpOnly rule', () => {
  assert.ok(H.isSessionCookieName('PHPSESSID'));
  assert.ok(H.isSessionCookieName('auth_token'));
  assert.ok(!H.isSessionCookieName('csrftoken'));
  assert.ok(!H.isSessionCookieName('XSRF-TOKEN'));
  assert.ok(!H.isSessionCookieName('theme'));
});

function ctx(over = {}) {
  return {
    url: 'https://example.com/', hostname: 'example.com', protocol: 'https:',
    headers: { csp: "default-src 'self'", hsts: 'max-age=1', xfo: null, xcto: 'nosniff', referrerPolicy: 'x', cookies: [] },
    redirectChain: { length: 0, crossDomainHops: 0 },
    dom: { forms: [], thirdPartyScripts: [], inlineScripts: [], mixedContentResources: [], iframes: [], sensitiveLinks: [], errorTextMatches: [], isLoginOrPaymentContext: false },
    ...over,
  };
}

test('rules: csrftoken without HttpOnly is no longer reported; real session cookie still is', () => {
  const c = ctx(); c.headers.cookies = [
    { name: 'csrftoken', secure: true, httpOnly: false, sameSite: true },
    { name: 'sessionid', secure: true, httpOnly: false, sameSite: true },
  ];
  const titles = Rules.runRules(c).map((f) => f.title);
  assert.ok(!titles.some((t) => /csrftoken/.test(t)));
  assert.ok(titles.some((t) => /sessionid.*HttpOnly/.test(t)));
});

test('rules: error-text finding quotes a fixed label, never page text', () => {
  const c = ctx(); c.dom.errorTextMatches = ['SQL syntax error message'];
  const f = Rules.runRules(c).find((x) => x.category === 'exposure');
  assert.match(f.evidence, /SQL syntax error message/);
});

test('rules: HTTP page is critical only in a login/payment context', () => {
  const a = Rules.runRules(ctx({ protocol: 'http:', url: 'http://example.com/' })).find((f) => /without HTTPS/.test(f.title));
  assert.equal(a.severity, 'high');
  const c = ctx({ protocol: 'http:', url: 'http://example.com/' }); c.dom.isLoginOrPaymentContext = true;
  assert.equal(Rules.runRules(c).find((f) => /without HTTPS/.test(f.title)).severity, 'critical');
});

test('scoring formula unchanged: one critical ~40, twenty info ~2 (regression vs v1.0)', () => {
  const crit = Scoring.computeRiskScore([{ severity: 'critical', confidence: 1, evidenceQuality: 1 }]);
  assert.equal(crit.score, 40);
  const infos = Array.from({ length: 20 }, () => ({ severity: 'info', confidence: 1, evidenceQuality: 1 }));
  assert.ok(Scoring.computeRiskScore(infos).score <= 3);
  const lowConf = Scoring.decide([{ severity: 'critical', confidence: 0.4, evidenceQuality: 0.3 }, { severity: 'critical', confidence: 0.4, evidenceQuality: 0.3 }, { severity: 'critical', confidence: 0.4, evidenceQuality: 0.3 }, { severity: 'critical', confidence: 0.4, evidenceQuality: 0.3 }]);
  assert.notEqual(lowConf.action, 'block', 'low-confidence evidence never blocks');
});

test('normalizeDomain', () => {
  const n = S.normalizeDomain;
  assert.equal(n('https://Example.com:8080/x?y=1#z'), 'example.com');
  assert.equal(n('user:pw@foo.com/path'), 'foo.com');
  assert.equal(n('*.foo.com'), 'foo.com');
  assert.equal(n('münchen.de'), 'xn--mnchen-3ya.de');
  assert.equal(n('1.2.3.4'), '1.2.3.4');
  assert.equal(n('a.com/<x>'), 'a.com');
  for (const bad of ['', 'exa mple.com', 'localhost', 'a..b.com', '-bad.com', 'http://', '<script>.com',
    '5', '123', '1.2.3', '0x7f.1', '999.1.1.1', 5, null, undefined]) assert.equal(n(bad), '', String(bad));
});

test('sanitizeSettings clamps and repairs corrupted/legacy settings', () => {
  const s = S.sanitizeSettings({ mode: 'weird', sensitivity: 'x', retentionDays: 5, maxHistoryPerDomain: 9999, allowlist: ['A.com', 'a.com', 'bad domain', 5], denylist: 'nope', backendUrl: 'http://evil.com', backendConsent: true });
  assert.equal(s.mode, 'auto'); assert.equal(s.sensitivity, 'balanced'); assert.equal(s.retentionDays, 30);
  assert.equal(s.maxHistoryPerDomain, 15);
  assert.deepEqual(s.allowlist, ['a.com']); assert.deepEqual(s.denylist, []);
  assert.equal(s.backendUrl, ''); assert.equal(s.backendConsent, false);
});

test('v1.0 settings blob (with maxHistoryPerDomain 25 and a backend URL) is migrated safely', () => {
  const v10 = { mode: 'auto', autoBlockCritical: true, sensitivity: 'balanced', retentionDays: 30, maxHistoryPerDomain: 25, backendUrl: 'https://api.example.com', backendToken: 'x', allowlist: [], denylist: [], installedAt: 1 };
  const s = S.sanitizeSettings(v10);
  assert.equal(s.maxHistoryPerDomain, 15);
  assert.equal(s.backendUrl, 'https://api.example.com');
  assert.equal(s.backendConsent, false, 'existing backend users must opt in again — consent is never assumed');
});
