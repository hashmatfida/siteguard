// Chrome Web Store policy audit of the PACKAGE ITSELF (pass a directory: the source folder or an extracted zip).
const fs = require('fs');
const path = require('path');
const root = path.resolve(process.argv[2] || path.join(__dirname, '../siteguard'));
let failures = 0;
const ok = (m) => console.log('  PASS  ' + m);
const bad = (m) => { failures++; console.log('  FAIL  ' + m); };
const check = (cond, m) => (cond ? ok(m) : bad(m));

const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const files = walk(root).map((f) => path.relative(root, f).split(path.sep).join('/'));
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');
const js = files.filter((f) => f.endsWith('.js'));
const html = files.filter((f) => f.endsWith('.html'));
const manifest = JSON.parse(read('manifest.json'));

console.log('\n[Yellow Magnesium] packaging — every file the manifest references exists, with exact case');
const refs = new Set();
const add = (p) => p && refs.add(p);
add(manifest.background?.service_worker);
(manifest.content_scripts || []).forEach((c) => [...(c.js || []), ...(c.css || [])].forEach(add));
add(manifest.action?.default_popup); add(manifest.options_ui?.page);
Object.values(manifest.icons || {}).forEach(add); Object.values(manifest.action?.default_icon || {}).forEach(add);
(manifest.declarative_net_request?.rule_resources || []).forEach((r) => add(r.path));
for (const r of refs) check(files.includes(r), `manifest references "${r}" and it is in the package (case-sensitive)`);
// local files referenced from HTML pages
for (const h of html) {
  const src = read(h);
  for (const m of src.matchAll(/(?:src|href)="([^"#]+)"/g)) {
    if (/^(https?:|chrome-extension:|data:)/.test(m[1])) continue;
    const resolved = path.posix.normalize(path.posix.join(path.posix.dirname(h), m[1]));
    check(files.includes(resolved), `${h} -> "${m[1]}" resolves to a packaged file`);
  }
}
check(files.includes('manifest.json'), 'manifest.json is at the package root');
check(!files.some((f) => f.startsWith('_')), 'no reserved underscore-prefixed files/folders (e.g. _metadata)');
check(!files.some((f) => /\.(md|zip|map|test\.js)$|(^|\/)\./.test(f)), 'no stray docs/zips/sourcemaps/dotfiles/tests in the package');
check(manifest.icons && ['16', '48', '128'].every((s) => files.includes(manifest.icons[s])), 'icons 16/48/128 present');

console.log('\n[Purple Potassium] permissions — every permission is used, none is superfluous');
const perms = manifest.permissions || [];
const allCode = js.map(read).join('\n');
const usage = {
  storage: /chrome\.storage\./, webRequest: /chrome\.webRequest\./, declarativeNetRequest: /chrome\.declarativeNetRequest\./,
  alarms: /chrome\.alarms\./, webNavigation: /chrome\.webNavigation\./, activeTab: /__never__/, tabs: /__never__/,
  cookies: /chrome\.cookies\./, history: /chrome\.history\./, scripting: /chrome\.scripting\./, downloads: /chrome\.downloads\./,
};
for (const p of perms) check(usage[p] && usage[p].test(allCode), `permission "${p}" is actually used by the code`);
for (const ns of ['alarms', 'webNavigation', 'cookies', 'history', 'scripting', 'downloads', 'tabs.executeScript']) {
  check(!new RegExp(`chrome\\.${ns.replace('.', '\\.')}\\b`).test(allCode) || perms.includes(ns.split('.')[0]), `no use of chrome.${ns} without permission`);
}
check(!perms.includes('alarms'), '"alarms" (the flagged permission) is removed from the manifest');
check(!perms.includes('activeTab') && !perms.includes('tabs') && !perms.includes('webNavigation'), 'redundant activeTab / tabs / webNavigation not requested');
check(!(manifest.optional_permissions || []).length, 'no optional_permissions declared');
check(JSON.stringify(manifest.host_permissions) === JSON.stringify(['http://*/*', 'https://*/*']), 'host_permissions limited to http/https (no file://, ftp, chrome://, or <all_urls>)');
const apiNamespaces = new Set([...allCode.matchAll(/chrome\.(\w+)\./g)].map((m) => m[1]));
console.log('        chrome.* namespaces used: ' + [...apiNamespaces].sort().join(', '));

console.log('\n[Blue Argon] Manifest V3 — no remotely hosted code');
check(manifest.manifest_version === 3, 'manifest_version is 3');
const execSites = [...allCode.matchAll(/(?<![\w.])(eval|Function)\s*\(/g)].filter((m) => {
  const line = allCode.slice(allCode.lastIndexOf('\n', m.index) + 1, allCode.indexOf('\n', m.index));
  return !/(match\(|\/\\b|reasons\.push|use\(s\)|RegExp|test\()/.test(line); // detection regexes / labels, not calls
});
check(execSites.length === 0, 'no eval()/Function() calls in extension code (only detection patterns inside heuristics.js regexes/labels)');
check(!/new Function\s*\(/.test(allCode), 'no new Function()');
check(!/setTimeout\(\s*['"`]|setInterval\(\s*['"`]/.test(allCode), 'no string-argument timers');
check(!/importScripts\(\s*['"`]https?:/.test(allCode), 'no remote importScripts');
check(!html.some((h) => /<script[^>]+src="https?:/i.test(read(h))), 'no remote <script src> in any HTML page');
check(!html.some((h) => /<script(?![^>]*\bsrc=)[^>]*>[^<]+<\/script>/i.test(read(h))), 'no inline <script> blocks (MV3 CSP)');
check(!html.some((h) => /\son\w+\s*=\s*"/i.test(read(h))), 'no inline event-handler attributes in HTML');
check(!manifest.content_security_policy, 'default MV3 content security policy is kept (not weakened)');
const fetchTargets = [...allCode.matchAll(/fetch\(([^)]*)\)/g)].map((m) => m[1].trim().slice(0, 60));
console.log('        fetch() call sites: ' + JSON.stringify(fetchTargets) + ' — backend JSON data only, parsed with JSON.parse, never executed');
check(fetchTargets.length === 1, 'exactly one network call site (the opt-in backend), returning data only');

console.log('\n[Red Titanium] obfuscation — code is readable');
check(!/['"`][A-Za-z0-9+/]{60,}={0,2}['"`]/.test(allCode), 'no long base64-like string literals');
check(!/\batob\s*\(|\bbtoa\s*\(/.test(allCode), 'no atob/btoa');
const escDensity = (allCode.match(/\\x[0-9a-fA-F]{2}|\\u[0-9a-fA-F]{4}/g) || []).length;
console.log('        \\x/\\u escape sequences in code: ' + escDensity + ' (all inside the readable detection regexes of heuristics.js)');
check(js.every((f) => read(f).split('\n').every((l) => l.length < 400)), 'no minified/very long lines in any script');
check(js.every((f) => /\n/.test(read(f)) && read(f).split('\n').length > 5), 'all scripts are multi-line, commented source');

console.log('\n[Purple Copper] secure transmission — no plain-HTTP endpoints in code');
const urls = [...allCode.matchAll(/['"`](https?:\/\/[^'"`\s$]+)['"`]/g)].map((m) => m[1]);
check(urls.every((u) => u.startsWith('https://') || /^http:\/\/(localhost|127\.0\.0\.1)/.test(u) || /^http:\/\/$/.test(u) || /^http:\/\/\*/.test(u)), 'no hard-coded http:// endpoints: ' + JSON.stringify(urls));
check(!/analytics|google-analytics|gtag|sentry|mixpanel|segment\.io|telemetry/i.test(allCode), 'no analytics / telemetry / crash-reporting SDKs');

console.log('\n[Single purpose / Spam / Redirection / Overrides]');
check(!manifest.chrome_url_overrides, 'no chrome_url_overrides (new tab / search / home page)');
check(!manifest.search_provider && !manifest.omnibox && !manifest.commands, 'no search provider, omnibox, or commands');
check(!/tabs\.create\(\s*\{\s*url:\s*['"`]https?:/.test(allCode), 'never opens external websites');
check(!/runtime\.onInstalled[\s\S]{0,400}tabs\.create/.test(allCode), 'does not open any page on install');
check(!/notifications\./.test(allCode), 'no notifications');

console.log('\n[Yellow Zinc / Red Nickel] metadata');
check(manifest.name.length > 0 && manifest.name.length <= 75, 'name present and ≤75 chars');
check(manifest.description.length > 0 && manifest.description.length <= 132, `description present and ≤132 chars (${manifest.description.length})`);
check(!/(best|#1|number one|editor'?s choice)/i.test(manifest.name + manifest.description), 'no superlatives / status claims in metadata');

console.log(failures ? `\n${failures} CHECK(S) FAILED` : '\nALL POLICY CHECKS PASSED');
process.exit(failures ? 1 : 0);
