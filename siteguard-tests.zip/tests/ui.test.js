const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const ROOT = process.env.SG_ROOT ? path.resolve(process.env.SG_ROOT) : path.resolve(__dirname, '../siteguard');
const read = (f) => fs.readFileSync(path.join(ROOT, f), 'utf8');
const tick = (ms = 30) => new Promise((r) => setTimeout(r, ms));

function memStorage(initial = {}) {
  const data = { ...initial };
  return {
    data,
    async get(keys) { const arr = Array.isArray(keys) ? keys : [keys]; const o = {}; for (const k of arr) if (k in data) o[k] = JSON.parse(JSON.stringify(data[k])); return o; },
    async set(o) { Object.assign(data, JSON.parse(JSON.stringify(o))); },
    async remove(k) { for (const key of (Array.isArray(k) ? k : [k])) delete data[key]; },
  };
}

/** Loads a real extension page (html + its scripts) into jsdom with a mocked chrome API. */
async function openPage(htmlPath, { chromeMock, url = 'chrome-extension://testid/' + htmlPath }) {
  const html = read(htmlPath).replace(/<script[^>]*src="[^"]*"[^>]*><\/script>/g, '');
  const dom = new JSDOM(html, { url, runScripts: 'outside-only', pretendToBeVisual: true });
  const errors = [];
  dom.window.addEventListener('error', (e) => errors.push(e.error || e.message));
  dom.window.chrome = chromeMock;
  dom.window.Element.prototype.scrollIntoView = () => {}; // not implemented by jsdom
  dom.window.confirm = () => true;
  const scripts = [...read(htmlPath).matchAll(/<script[^>]*src="([^"]*)"[^>]*><\/script>/g)].map((m) => m[1]);
  for (const src of scripts) {
    const file = path.posix.normalize(path.posix.join(path.posix.dirname(htmlPath), src));
    dom.window.eval(read(file));
  }
  await tick();
  return { dom, doc: dom.window.document, errors };
}

const visible = (doc, id) => !doc.getElementById(id).classList.contains('hidden');

function popupChrome({ tabUrl, state, scanReply, mode = 'auto', history = [] }) {
  const local = memStorage({ 'sg:history:example.com': history });
  const calls = [];
  return {
    calls,
    storage: { local, session: memStorage(), onChanged: { addListener() {} } },
    tabs: { query: async () => [{ id: 7, url: tabUrl }], create: async (o) => calls.push(['create', o]) },
    runtime: {
      getURL: (p) => 'chrome-extension://testid/' + p, openOptionsPage: () => calls.push(['options']),
      sendMessage: async (msg) => {
        calls.push([msg.type]);
        if (msg.type === 'SG_GET_TAB_STATE') return { ok: true, mode, ...state() };
        if (msg.type === 'SG_SCAN_NOW') return { ok: true, ...(scanReply || { status: 'pending' }) };
        return { ok: true };
      },
    },
  };
}

const RESULT = {
  url: 'https://example.com/', score: 62, band: { key: 'high', label: 'High' }, action: 'warn', findingsTotal: 3, timestamp: Date.now(),
  explanation: { recommendation: 'Review the reasons.', factors: [
    { title: '<img src=x onerror="window.__xss=1">Weak thing', contributionLabel: 'High', evidenceTypeLabel: 'Detected fact', evidence: '<script>window.__xss=2</script>' },
  ] },
};

test('popup: non-http tab shows the "only http(s)" message', async () => {
  const { doc, errors } = await openPage('popup/popup.html', { chromeMock: popupChrome({ tabUrl: 'chrome://extensions', state: () => ({ ready: false }) }) });
  assert.ok(visible(doc, 'notHttp')); assert.equal(errors.length, 0);
});

test('popup: Chrome Web Store page gets an immediate explanation instead of a spinner', async () => {
  const { doc } = await openPage('popup/popup.html', { chromeMock: popupChrome({ tabUrl: 'https://chromewebstore.google.com/detail/x', state: () => ({ ready: false }) }) });
  assert.ok(visible(doc, 'notHttp'));
  assert.match(doc.getElementById('notHttpMsg').textContent, /Chrome Web Store/);
  assert.ok(!visible(doc, 'loading'));
});

test('popup: live result renders; hostile strings are escaped (no injected elements / script)', async () => {
  const { doc, dom, errors } = await openPage('popup/popup.html', { chromeMock: popupChrome({ tabUrl: 'https://example.com/', state: () => ({ ready: true, result: RESULT }) }) });
  assert.ok(visible(doc, 'content'));
  assert.equal(doc.getElementById('scoreNum').textContent, '62');
  assert.equal(doc.getElementById('bandLabel').textContent, 'High risk');
  assert.equal(doc.getElementById('findingsCount').textContent, '3 findings');
  assert.equal(doc.querySelectorAll('#factors img, #factors script').length, 0);
  assert.equal(dom.window.__xss, undefined);
  assert.ok(doc.getElementById('staleNote').classList.contains('hidden'));
  assert.equal(errors.length, 0);
});

test('popup: allow-listed result is labelled "Allow-listed / Not scanned", not "0 Very Low"', async () => {
  const r = { ...RESULT, forcedAllow: true, score: 0, band: { key: 'very_low', label: 'Very Low' }, findingsTotal: 0, explanation: { recommendation: 'On allow list', factors: [] } };
  const { doc } = await openPage('popup/popup.html', { chromeMock: popupChrome({ tabUrl: 'https://example.com/', state: () => ({ ready: true, result: r }) }) });
  assert.equal(doc.getElementById('bandLabel').textContent, 'Allow-listed');
  assert.equal(doc.getElementById('findingsCount').textContent, 'Not scanned');
});

test('popup: backend outage is communicated', async () => {
  const { doc } = await openPage('popup/popup.html', { chromeMock: popupChrome({ tabUrl: 'https://example.com/', state: () => ({ ready: true, result: { ...RESULT, backend: 'unavailable' } }) }) });
  assert.ok(!doc.getElementById('backendNote').classList.contains('hidden'));
  assert.match(doc.getElementById('backendNote').textContent, /local checks only/);
});

test('popup: manual mode with no captured headers asks the user to reload', async () => {
  const { doc } = await openPage('popup/popup.html', { chromeMock: popupChrome({ tabUrl: 'https://example.com/', mode: 'manual', state: () => ({ ready: false }), scanReply: { status: 'needs_reload' } }) });
  assert.ok(visible(doc, 'needsReload'));
});

test('popup: no result ever arrives -> falls back to last saved scan, clearly labelled', async () => {
  const saved = { ...RESULT, timestamp: Date.now() - 86400000 };
  const mock = popupChrome({ tabUrl: 'https://example.com/', state: () => ({ ready: false }), history: [saved] });
  const { doc, dom } = await openPage('popup/popup.html', { chromeMock: mock });
  assert.ok(visible(doc, 'loading'));
  const realNow = dom.window.Date.now; dom.window.Date.now = () => realNow() + 60000; // jump past the 10s poll timeout
  await tick(700);
  assert.ok(visible(doc, 'content'));
  assert.ok(!doc.getElementById('staleNote').classList.contains('hidden'));
  assert.match(doc.getElementById('staleNote').textContent, /last saved scan/);
});

test('popup: no result and no history -> explanatory timeout state (never an endless spinner)', async () => {
  const mock = popupChrome({ tabUrl: 'https://example.com/', state: () => ({ ready: false }) });
  const { doc, dom } = await openPage('popup/popup.html', { chromeMock: mock });
  const realNow = dom.window.Date.now; dom.window.Date.now = () => realNow() + 60000;
  await tick(700);
  assert.ok(visible(doc, 'timeout'));
  assert.ok(!visible(doc, 'loading'));
});

test('popup: Rescan and false-positive buttons talk to the worker; FP label is honest', async () => {
  const mock = popupChrome({ tabUrl: 'https://example.com/', state: () => ({ ready: true, result: RESULT }) });
  const { doc } = await openPage('popup/popup.html', { chromeMock: mock });
  doc.getElementById('fpBtn').click(); await tick();
  assert.ok(mock.calls.some((c) => c[0] === 'SG_FALSE_POSITIVE'));
  assert.equal(doc.getElementById('fpBtn').textContent, 'Saved on this device');
  doc.getElementById('reportBtn').click(); await tick();
  assert.ok(mock.calls.some((c) => c[0] === 'create' && /report\.html\?domain=example\.com/.test(c[1].url)));
});

// ---------------------------------------------------------------- options

function optionsChrome(settings) {
  const local = memStorage(settings ? { 'sg:settings': settings } : {});
  return { storage: { local, session: memStorage(), onChanged: { addListener() {} } }, runtime: { getURL: (p) => p }, __local: local };
}

test('options: loads defaults, no script errors, permission list matches the manifest (no alarms/webNavigation)', async () => {
  const { doc, errors } = await openPage('options/options.html', { chromeMock: optionsChrome() });
  assert.equal(errors.length, 0);
  const text = doc.querySelector('.perm-list').textContent;
  for (const p of ['webRequest', 'declarativeNetRequest', 'storage']) assert.ok(text.includes(p), p);
  const note = [...doc.querySelectorAll('.note')].map((n) => n.textContent).join(' ');
  assert.match(note, /does not request the history, cookies, tabs, webNavigation or alarms permissions/);
  assert.ok(!/periodically refresh/.test(doc.body.textContent), 'stale alarms explanation removed');
  const manifest = JSON.parse(read('manifest.json'));
  assert.deepEqual(manifest.permissions.sort(), ['declarativeNetRequest', 'storage', 'webRequest']);
});

test('options: invalid domain shows an error; valid domain is added; adding to one list removes it from the other', async () => {
  const mock = optionsChrome();
  const { doc } = await openPage('options/options.html', { chromeMock: mock });
  doc.getElementById('allowInput').value = 'not a domain'; doc.getElementById('allowAdd').click(); await tick();
  assert.ok(!doc.getElementById('allowError').classList.contains('hidden'));
  doc.getElementById('allowInput').value = 'https://Example.com/path'; doc.getElementById('allowAdd').click(); await tick(60);
  assert.ok(doc.getElementById('allowList').textContent.includes('example.com'));
  doc.getElementById('denyInput').value = 'example.com'; doc.getElementById('denyAdd').click(); await tick(60);
  assert.ok(doc.getElementById('denyList').textContent.includes('example.com'));
  assert.ok(!doc.getElementById('allowList').textContent.includes('example.com'), 'moved, not duplicated');
});

test('options: backend URL must be https; consent box stays disabled until a valid URL is saved; consent resets when the server changes', async () => {
  const mock = optionsChrome();
  const { doc, dom } = await openPage('options/options.html', { chromeMock: mock });
  const url = doc.getElementById('backendUrl'); const consent = doc.getElementById('backendConsent');
  assert.equal(consent.disabled, true);
  url.value = 'http://api.example.com'; url.dispatchEvent(new dom.window.Event('change')); await tick(60);
  assert.ok(!doc.getElementById('backendError').classList.contains('hidden'));
  assert.equal(mock.__local.data['sg:settings']?.backendUrl || '', '');
  url.value = 'https://api.example.com/'; url.dispatchEvent(new dom.window.Event('change')); await tick(80);
  assert.equal(mock.__local.data['sg:settings'].backendUrl, 'https://api.example.com');
  assert.equal(consent.disabled, false); assert.equal(consent.checked, false);
  consent.checked = true; consent.dispatchEvent(new dom.window.Event('change')); await tick(60);
  assert.equal(mock.__local.data['sg:settings'].backendConsent, true);
  url.value = 'https://other.example.com'; url.dispatchEvent(new dom.window.Event('change')); await tick(80);
  assert.equal(mock.__local.data['sg:settings'].backendConsent, false, 'consent does not carry over to a different server');
});

test('options: hostile list entries are escaped when rendered', async () => {
  const mock = optionsChrome({ allowlist: ['<img src=x onerror=window.__x=1>.com'] });
  const { doc, dom } = await openPage('options/options.html', { chromeMock: mock });
  assert.equal(doc.querySelectorAll('#allowList img').length, 0); assert.equal(dom.window.__x, undefined);
});

// ---------------------------------------------------------------- report

function reportChrome(history) {
  return { storage: { local: memStorage({ 'sg:history:example.com': history }), session: memStorage(), onChanged: { addListener() {} } }, runtime: { getURL: (p) => p } };
}

test('report: renders findings; malicious severity/class/text from storage cannot inject markup', async () => {
  const entry = { ...RESULT, findings: [
    { id: '1', category: '<b>cat</b>', title: '<img src=x onerror=window.__r=1>', severity: '"><svg onload=window.__r=2>', confidence: 0.9, evidenceQuality: 1, evidence: '<script>window.__r=3</script>', evidenceType: 'detected', remediation: '<i>fix</i>', cwe: 'CWE-1' },
    { id: '2', category: 'headers', title: 'Normal', severity: 'medium', confidence: 1, evidenceQuality: 1, evidence: 'ok', evidenceType: 'inference' },
  ] };
  const { doc, dom, errors } = await openPage('report/report.html', { chromeMock: reportChrome([entry]), url: 'chrome-extension://testid/report/report.html?domain=example.com' });
  assert.equal(errors.length, 0);
  assert.ok(visible(doc, 'main'));
  assert.equal(doc.querySelectorAll('.finding-card').length, 2);
  assert.equal(doc.querySelectorAll('#findingsList img, #findingsList svg, #findingsList script, #findingsList b, #findingsList i').length, 0);
  assert.equal(dom.window.__r, undefined);
});

test('report: the "how this works" explainer is visible even when the domain has no history (v1.0 hid it)', async () => {
  const { doc } = await openPage('report/report.html', { chromeMock: reportChrome([]), url: 'chrome-extension://testid/report/report.html?domain=example.com&explainer=1' });
  assert.ok(visible(doc, 'empty'));
  assert.ok(doc.getElementById('howitworks'));
  assert.equal(doc.getElementById('howitworks').closest('main'), null, 'explainer sits outside the hidden <main>');
});

test('report: privacy copy matches v1.1 behaviour (consent required, no query strings)', async () => {
  const { doc } = await openPage('report/report.html', { chromeMock: reportChrome([]), url: 'chrome-extension://testid/report/report.html?domain=example.com' });
  const text = doc.getElementById('howitworks').textContent.replace(/\s+/g, ' ');
  assert.match(text, /tick the consent box/);
  assert.match(text, /without its query string/);
  assert.match(text, /never full URLs, page content, or cookies/);
  assert.ok(!/unless you explicitly configure a backend URL/.test(text), 'old v1.0 wording is gone');
});
