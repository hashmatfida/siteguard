const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const ROOT = process.env.SG_ROOT ? path.resolve(process.env.SG_ROOT) : path.resolve(__dirname, '../siteguard');
const read = (f) => fs.readFileSync(path.join(ROOT, f), 'utf8');
const tick = (ms = 120) => new Promise((r) => setTimeout(r, ms));

const PAGE = `<!doctype html><html><head><title>Sign in to your account</title>
<script src="https://cdn.thirdparty.test/lib.js?key=SECRETKEY"></script>
<script src="/local.js"></script>
<script>eval("a");eval("b");eval("c");var x="${'A'.repeat(100)}";${'\\x41'.repeat(25)}</script>
<meta http-equiv="refresh" content="5;url=/x">
</head><body>
<form action="http://evil.test/collect?sid=SECRETSID"><input type="password" name="p"></form>
<img src="http://insecure.test/pic.png?session=SECRETSESSION">
<iframe src="https://ads.test/x" style="display:none"></iframe>
<a href="/site/.env?token=SECRETTOKEN">cfg</a>
<p>You have an error in your SQL syntax near 'SECRET_PAGE_TEXT'</p>
</body></html>`;

function boot() {
  const sent = [];
  const listeners = [];
  const dom = new JSDOM(PAGE, { url: 'https://example.com/login?token=URLSECRET', runScripts: 'outside-only', pretendToBeVisual: true });
  const w = dom.window;
  Object.defineProperty(w.HTMLElement.prototype, 'innerText', { get() { return this.textContent; } }); // jsdom lacks innerText
  const shadows = [];
  const realAttach = w.Element.prototype.attachShadow;
  w.Element.prototype.attachShadow = function (init) { const r = realAttach.call(this, { ...init, mode: 'open' }); shadows.push(r); return r; }; // test-only: make the closed root inspectable
  w.chrome = {
    runtime: {
      lastError: undefined,
      sendMessage: (m, cb) => { sent.push(m); if (cb) cb({ ok: true }); },
      onMessage: { addListener: (fn) => listeners.push(fn) },
    },
  };
  w.eval(read('lib/heuristics.js'));
  w.eval(read('content.js'));
  const deliver = (msg) => listeners.forEach((fn) => fn(msg, {}, () => {}));
  return { w, sent, shadows, deliver };
}

test('content script: sends structured signals only — no query strings, no page text, no cookie data', async () => {
  const { sent } = boot();
  await tick();
  const msg = sent.find((m) => m.type === 'SG_SIGNALS');
  assert.ok(msg, 'SG_SIGNALS was sent');
  const raw = JSON.stringify(msg);
  for (const secret of ['SECRETKEY', 'SECRETSID', 'SECRETSESSION', 'SECRETTOKEN', 'SECRET_PAGE_TEXT']) assert.ok(!raw.includes(secret), 'leaked: ' + secret);
  const s = JSON.parse(JSON.stringify(msg.signals)); // normalise objects from jsdom's separate realm
  assert.equal(s.forms[0].hasPassword, true);
  assert.equal(s.forms[0].actionIsHttp, true);
  assert.equal(s.forms[0].actionIsCrossOrigin, true);
  assert.deepEqual(s.thirdPartyScripts, [{ hostname: 'cdn.thirdparty.test' }]);
  assert.equal(s.mixedContentResources[0].url, 'http://insecure.test/pic.png');
  assert.equal(s.sensitiveLinks[0].href, 'https://example.com/site/.env');
  assert.deepEqual(s.errorTextMatches, ['SQL syntax error message'], 'fixed label, not copied page text');
  assert.ok(s.inlineScripts[0].obfuscation.score >= 4);
  assert.equal(s.hasMetaRefresh, true);
  assert.equal(s.isLoginOrPaymentContext, true);
  assert.ok(s.iframes.some((f) => f.hidden));
});

test('content script: SG_COLLECT re-sends signals on request (manual-mode scan)', async () => {
  const { sent, deliver } = boot();
  await tick();
  const before = sent.filter((m) => m.type === 'SG_SIGNALS').length;
  deliver({ type: 'SG_COLLECT' });
  assert.equal(sent.filter((m) => m.type === 'SG_SIGNALS').length, before + 1);
});

const EXPL = {
  domain: 'example.com', score: 82, band: { key: 'critical', label: 'Critical' }, headline: 'Risk Score: 82/100 — Critical Risk',
  factors: [{ title: '<img src=x onerror="window.__x=1">Bad', contributionLabel: 'High', evidenceTypeLabel: 'Detected fact', evidence: '<script>window.__x=2</script>', confidence: 0.9 }],
};

test('overlay: clearly branded as SiteGuard, hostile strings escaped, buttons work', async () => {
  const { w, sent, shadows, deliver } = boot();
  await tick();
  deliver({ type: 'SG_SHOW_BLOCK', explanation: EXPL, policyLocked: false });
  const root = shadows[0];
  const text = root.textContent.replace(/\s+/g, ' ');
  assert.match(text, /SiteGuard extension/);
  assert.match(text, /not from Chrome or your operating system/);
  assert.match(text, /flagged this site as risky/);
  assert.equal(root.querySelectorAll('img, script').length, 0);
  assert.equal(w.__x, undefined);
  root.getElementById('sg-continue').click();
  assert.ok(sent.some((m) => m.type === 'SG_ALLOW_ONCE'));
  assert.equal(w.document.getElementById('siteguard-shadow-host'), null, 'overlay removed after continue');
});

test('overlay: policy-locked (score>=90) has no "Continue anyway"; false-positive is local and acknowledged', async () => {
  const { sent, shadows, deliver } = boot();
  await tick();
  deliver({ type: 'SG_SHOW_BLOCK', explanation: EXPL, policyLocked: true });
  const root = shadows[0];
  assert.equal(root.getElementById('sg-continue'), null);
  root.getElementById('sg-fp').click();
  assert.ok(sent.some((m) => m.type === 'SG_FALSE_POSITIVE'));
  assert.equal(root.getElementById('sg-fp').textContent, 'Saved on this device');
});

test('banner: labelled "SiteGuard:", dismissible; SG_HIDE removes it', async () => {
  const { w, shadows, deliver } = boot();
  await tick();
  deliver({ type: 'SG_SHOW_WARN', explanation: { ...EXPL, band: { key: 'high', label: 'High' } } });
  assert.match(shadows[0].textContent, /SiteGuard:/);
  shadows[0].getElementById('sg-dismiss').click();
  assert.equal(w.document.getElementById('siteguard-shadow-host'), null);
  deliver({ type: 'SG_SHOW_WARN', explanation: EXPL });
  deliver({ type: 'SG_HIDE' });
  assert.equal(w.document.getElementById('siteguard-shadow-host'), null);
});

test('content script: injecting twice does not double-send or throw', async () => {
  const { w, sent } = boot();
  await tick();
  const n = sent.filter((m) => m.type === 'SG_SIGNALS').length;
  w.eval(read('content.js'));
  await tick();
  assert.equal(sent.filter((m) => m.type === 'SG_SIGNALS').length, n);
});
