// Test harness: loads the REAL background.js into a vm sandbox with a mocked chrome API.
const vm = require('vm');
const fs = require('fs');
const path = require('path');

const ROOT = process.env.SG_ROOT ? path.resolve(process.env.SG_ROOT) : path.resolve(__dirname, '../siteguard');
const EXT_ORIGIN = 'chrome-extension://testid/';

function makeStorageArea(shared) {
  const data = shared || {};
  const listeners = [];
  const pick = (keys) => {
    if (keys == null) return { ...data };
    const arr = Array.isArray(keys) ? keys : typeof keys === 'string' ? [keys] : Object.keys(keys);
    const out = {};
    for (const k of arr) if (k in data) out[k] = JSON.parse(JSON.stringify(data[k]));
    return out;
  };
  return {
    data,
    listeners,
    async get(keys) { return pick(keys); },
    async set(obj) {
      const changes = {};
      for (const [k, v] of Object.entries(obj)) {
        const oldValue = k in data ? JSON.parse(JSON.stringify(data[k])) : undefined;
        data[k] = JSON.parse(JSON.stringify(v));
        changes[k] = { oldValue, newValue: JSON.parse(JSON.stringify(v)) };
      }
      listeners.forEach((l) => l(changes));
    },
    async remove(keys) {
      for (const k of (Array.isArray(keys) ? keys : [keys])) delete data[k];
    },
  };
}

function makeEvent() {
  const listeners = [];
  return { listeners, addListener(fn, ...rest) { listeners.push({ fn, rest }); } };
}

/** Creates one "service worker instance". Pass the same `shared` stores to simulate a restart. */
function createWorker(shared = {}, opts = {}) {
  shared.local = shared.local || {};
  shared.session = shared.session || {};
  shared.dnr = shared.dnr || [];
  const local = makeStorageArea(shared.local);
  const session = makeStorageArea(shared.session);

  const sent = [];       // tabs.sendMessage calls
  const badges = {};     // tabId -> text
  const created = [];    // tabs.create
  const reloaded = [];   // tabs.reload
  const fetchCalls = [];

  const chrome = {
    runtime: {
      getURL: (p) => EXT_ORIGIN + p,
      onMessage: makeEvent(), onInstalled: makeEvent(), onStartup: makeEvent(),
      lastError: undefined,
    },
    storage: {
      local, session,
      onChanged: { addListener(fn) {
        local.listeners.push((c) => fn(c, 'local'));
        session.listeners.push((c) => fn(c, 'session'));
      } },
    },
    webRequest: { onBeforeRequest: makeEvent(), onBeforeRedirect: makeEvent(), onHeadersReceived: makeEvent() },
    tabs: {
      onUpdated: makeEvent(), onRemoved: makeEvent(),
      sendMessage(tabId, msg, cb) { sent.push({ tabId, msg }); if (typeof cb === 'function') cb(); return Promise.resolve({ ok: true }); },
      async create(o) { created.push(o); },
      async reload(id) { reloaded.push(id); },
    },
    action: {
      async setBadgeText({ tabId, text }) { badges[tabId] = text; },
      async setBadgeBackgroundColor() {},
    },
    declarativeNetRequest: {
      async getDynamicRules() { return JSON.parse(JSON.stringify(shared.dnr)); },
      async updateDynamicRules({ removeRuleIds = [], addRules = [] }) {
        if (opts.dnrReject) for (const r of addRules) opts.dnrReject(r);
        const kept = shared.dnr.filter((r) => !removeRuleIds.includes(r.id));
        shared.dnr.length = 0;
        shared.dnr.push(...kept, ...JSON.parse(JSON.stringify(addRules)));
      },
    },
    // Anything not listed above must NOT be touched by the extension:
    alarms: new Proxy({}, { get() { throw new Error('chrome.alarms must not be used'); } }),
    webNavigation: new Proxy({}, { get() { throw new Error('chrome.webNavigation must not be used'); } }),
  };

  const sandbox = {
    chrome, console, URL, URLSearchParams, AbortController, setTimeout, clearTimeout, JSON, Promise, Date, Math, Set, Map,
    fetch: async (url, init) => {
      fetchCalls.push({ url, init });
      return opts.fetchImpl ? opts.fetchImpl(url, init) : { ok: false };
    },
  };
  sandbox.self = sandbox;
  sandbox.importScripts = (...files) => {
    for (const f of files) vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sandbox, { filename: f });
  };
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8'), sandbox, { filename: 'background.js' });

  const L = (ev) => ev.listeners.map((x) => x.fn);
  const fire = (ev, ...args) => L(ev).forEach((fn) => fn(...args));

  const worker = {
    chrome, sandbox, shared, sent, badges, created, reloaded, fetchCalls,
    store: sandbox.SiteGuardStorage,
    async settle() { for (let i = 0; i < 30; i++) await new Promise((r) => setImmediate(r)); },
    beforeRequest(tabId, url, requestId) { fire(chrome.webRequest.onBeforeRequest, { tabId, url, requestId, type: 'main_frame' }); },
    beforeRedirect(tabId, url, redirectUrl, requestId) { fire(chrome.webRequest.onBeforeRedirect, { tabId, url, redirectUrl, requestId, type: 'main_frame' }); },
    headersReceived(tabId, url, requestId, headers = [], statusCode = 200) {
      fire(chrome.webRequest.onHeadersReceived, {
        tabId, url, requestId, statusCode, type: 'main_frame',
        responseHeaders: headers.map(([name, value]) => ({ name, value })),
      });
    },
    message(msg, sender) {
      return new Promise((resolve) => {
        let handled = false;
        L(chrome.runtime.onMessage).forEach((fn) => { handled = fn(msg, sender, resolve) || handled; });
      });
    },
    fromContent(tabId, url) { return { tab: { id: tabId }, url }; },
    fromPopup() { return { url: EXT_ORIGIN + 'popup/popup.html' }; },
    async install(reason = 'install') { for (const fn of L(chrome.runtime.onInstalled)) await fn({ reason }); },
    fire, L,
  };
  return worker;
}

const GOOD_HEADERS = [
  ['Content-Security-Policy', "default-src 'self'; script-src 'self'; object-src 'none'; frame-ancestors 'none'"],
  ['Strict-Transport-Security', 'max-age=31536000'],
  ['X-Content-Type-Options', 'nosniff'],
  ['Referrer-Policy', 'no-referrer'],
  ['Set-Cookie', 'sid=abc; Secure; HttpOnly; SameSite=Lax'],
];
const CLEAN_SIGNALS = {
  forms: [], thirdPartyScripts: [], inlineScripts: [], mixedContentResources: [], iframes: [],
  sensitiveLinks: [], errorTextMatches: [], hasMetaRefresh: false, isLoginOrPaymentContext: false,
};

module.exports = { createWorker, GOOD_HEADERS, CLEAN_SIGNALS, EXT_ORIGIN, ROOT };
