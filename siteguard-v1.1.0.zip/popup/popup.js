const $ = (id) => document.getElementById(id);
const els = {
  loading: $('loading'),
  content: $('content'),
  notHttp: $('notHttp'),
  needsReload: $('needsReload'),
  timeout: $('timeout'),
  domain: $('domain'),
  gauge: $('gauge'),
  scoreNum: $('scoreNum'),
  bandLabel: $('bandLabel'),
  findingsCount: $('findingsCount'),
  staleNote: $('staleNote'),
  backendNote: $('backendNote'),
  notHttpMsg: $('notHttpMsg'),
  recommendation: $('recommendation'),
  factors: $('factors'),
  reportBtn: $('reportBtn'),
  rescanBtn: $('rescanBtn'),
  reloadBtn: $('reloadBtn'),
  retryBtn: $('retryBtn'),
  fpBtn: $('fpBtn'),
  settingsBtn: $('settingsBtn'),
  whyLink: $('whyLink'),
};

const POLL_INTERVAL_MS = 500;
const POLL_TIMEOUT_MS = 10000;

let currentTab = null;
let activeDomain = null;
let pollTimer = null;

function showState(name) {
  for (const key of ['loading', 'content', 'notHttp', 'needsReload', 'timeout']) {
    els[key].classList.toggle('hidden', key !== name);
  }
}

function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// The service worker may be asleep; sendMessage wakes it. Resolves to null on failure.
function bg(message) {
  return chrome.runtime.sendMessage(message).catch(() => null);
}

function render(entry, live) {
  showState('content');
  els.domain.textContent = activeDomain;

  if (entry.forcedAllow) {
    els.gauge.className = 'gauge allow';
    els.scoreNum.textContent = '✓';
    els.bandLabel.textContent = 'Allow-listed';
    els.findingsCount.textContent = 'Not scanned';
  } else {
    const key = entry.band?.key || 'low';
    els.gauge.className = 'gauge ' + (key === 'very_low' ? 'low' : key);
    els.scoreNum.textContent = entry.score;
    els.bandLabel.textContent = (entry.band?.label || '—') + ' risk';
    const count = entry.findingsTotal ?? (entry.findings || []).length;
    els.findingsCount.textContent = `${count} finding${count === 1 ? '' : 's'}`;
  }

  if (live) {
    els.staleNote.classList.add('hidden');
  } else {
    els.staleNote.textContent = `Showing the last saved scan of this site (${new Date(entry.timestamp).toLocaleString()}).`;
    els.staleNote.classList.remove('hidden');
  }

  if (entry.backend === 'unavailable') {
    els.backendNote.textContent = 'Your optional analysis backend did not respond, so this result uses SiteGuard\'s local checks only.';
    els.backendNote.classList.remove('hidden');
  } else {
    els.backendNote.classList.add('hidden');
  }

  const explanation = entry.explanation || {};
  els.recommendation.textContent = explanation.recommendation || 'No summary available.';

  els.factors.innerHTML = (explanation.factors || []).slice(0, 3).map((f) => `
    <li>
      <span class="tag">${escapeHtml(f.contributionLabel)}</span>
      <span class="tag">${escapeHtml(f.evidenceTypeLabel)}</span>
      <div class="title">${escapeHtml(f.title)}</div>
      <div class="ev">${escapeHtml(f.evidence)}</div>
    </li>
  `).join('') || '<li class="ev">No notable findings.</li>';
}

async function fetchState() {
  const state = await bg({ type: 'SG_GET_TAB_STATE', tabId: currentTab.id });
  return state && state.ok ? state : null;
}

function stopPolling() {
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
}

async function fallBackToHistory() {
  try {
    const history = await SiteGuardStorage.getHistory(activeDomain);
    if (history.length > 0) { render(history[0], false); return; }
  } catch (_) { /* fall through */ }
  showState('timeout');
}

function startPolling() {
  stopPolling();
  const startedAt = Date.now();
  pollTimer = setInterval(async () => {
    const state = await fetchState();
    if (state && state.ready) {
      stopPolling();
      render(state.result, true);
    } else if (Date.now() - startedAt > POLL_TIMEOUT_MS) {
      stopPolling();
      fallBackToHistory();
    }
  }, POLL_INTERVAL_MS);
}

async function requestScan() {
  showState('loading');
  const state = await fetchState();
  if (state && state.ready) { render(state.result, true); return; }
  if (state && state.mode === 'manual') {
    const reply = await bg({ type: 'SG_SCAN_NOW', tabId: currentTab.id });
    if (reply && reply.status === 'needs_reload') { showState('needsReload'); return; }
    if (reply && reply.status === 'ready') {
      const fresh = await fetchState();
      if (fresh && fresh.ready) { render(fresh.result, true); return; }
    }
  }
  startPolling();
}

async function rescan() {
  if (currentTab) await bg({ type: 'SG_RESCAN', tabId: currentTab.id });
  window.close();
}

// Pages where Chrome itself prevents extensions from running — say so immediately instead of spinning.
function isRestrictedPage(urlString) {
  try {
    const u = new URL(urlString);
    return u.hostname === 'chromewebstore.google.com' ||
      (u.hostname === 'chrome.google.com' && u.pathname.startsWith('/webstore'));
  } catch (_) { return false; }
}

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTab = tab;
  if (!tab || !/^https?:\/\//i.test(tab.url || '')) {
    showState('notHttp');
    return;
  }
  if (isRestrictedPage(tab.url)) {
    els.notHttpMsg.textContent = 'Chrome does not allow extensions to scan the Chrome Web Store, so there is nothing to show for this page.';
    showState('notHttp');
    return;
  }
  activeDomain = new URL(tab.url).hostname;
  await requestScan();
}

els.reportBtn.addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL(`report/report.html?domain=${encodeURIComponent(activeDomain)}`) });
});
els.rescanBtn.addEventListener('click', rescan);
els.reloadBtn.addEventListener('click', rescan);
els.retryBtn.addEventListener('click', rescan);
els.fpBtn.addEventListener('click', async () => {
  els.fpBtn.disabled = true;
  await bg({ type: 'SG_FALSE_POSITIVE', domain: activeDomain });
  els.fpBtn.textContent = 'Saved on this device';
});
els.settingsBtn.addEventListener('click', () => chrome.runtime.openOptionsPage());
els.whyLink.addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: chrome.runtime.getURL('report/report.html?domain=' + encodeURIComponent(activeDomain || '') + '&explainer=1') });
});

init();
