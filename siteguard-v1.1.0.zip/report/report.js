const SEV_ORDER = ['critical', 'high', 'medium', 'low', 'info'];
const SEV_LABEL = { critical: 'Critical', high: 'High', medium: 'Medium', low: 'Low', info: 'Informational' };
const EV_LABEL = { detected: 'Detected fact', inference: 'Heuristic inference', external: 'External evidence' };

function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function fmtTime(ts) {
  return new Date(ts).toLocaleString();
}
// Anything not in the known list is rendered as 'info' — stored data is never trusted for class names.
function safeSeverity(s) {
  return SEV_ORDER.includes(s) ? s : 'info';
}

async function init() {
  const params = new URLSearchParams(location.search);
  const domain = params.get('domain') || '';
  document.getElementById('domain').textContent = domain || '(unknown domain)';

  if (params.get('explainer') === '1') {
    document.getElementById('howitworks').scrollIntoView({ behavior: 'smooth' });
  }

  const history = domain ? await SiteGuardStorage.getHistory(domain) : [];
  if (history.length === 0) {
    document.getElementById('empty').classList.remove('hidden');
    return;
  }
  document.getElementById('main').classList.remove('hidden');

  const latest = history[0];
  renderSummary(latest);
  renderSeverity(latest.findings || []);
  renderFindings(latest.findings || []);
  renderHistory(history);
}

function renderSummary(entry) {
  const gauge = document.getElementById('gauge');
  if (entry.forcedAllow) {
    gauge.className = 'gauge';
    document.getElementById('scoreNum').textContent = '✓';
    document.getElementById('bandLabel').textContent = 'Allow-listed (not scanned)';
  } else {
    const key = entry.band?.key === 'very_low' ? 'low' : (entry.band?.key || 'low');
    gauge.className = 'gauge ' + (['low', 'moderate', 'high', 'critical'].includes(key) ? key : 'low');
    document.getElementById('scoreNum').textContent = entry.score;
    document.getElementById('bandLabel').textContent = (entry.band?.label || '—') + ' risk';
  }
  document.getElementById('timestamp').textContent = fmtTime(entry.timestamp);
  const count = entry.findingsTotal ?? (entry.findings || []).length;
  document.getElementById('findingsCount').textContent = `${count} finding${count === 1 ? '' : 's'} · action: ${entry.action}`;
  document.getElementById('recommendation').textContent = entry.explanation?.recommendation || '';
  const backendNote = document.getElementById('backendNote');
  if (entry.backend === 'unavailable') {
    backendNote.textContent = 'Your optional analysis backend did not respond during this scan, so only local checks are included.';
    backendNote.classList.remove('hidden');
  }
}

function renderSeverity(findings) {
  const counts = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
  for (const f of findings) counts[safeSeverity(f.severity)] += 1;
  const max = Math.max(1, ...Object.values(counts));
  document.getElementById('severityBars').innerHTML = SEV_ORDER.map((s) => `
    <div class="sev-row">
      <span>${SEV_LABEL[s]}</span>
      <div class="sev-track"><div class="sev-fill ${s}" style="width:${(counts[s] / max) * 100}%"></div></div>
      <span>${counts[s]}</span>
    </div>
  `).join('');
}

function renderFindings(findings) {
  const el = document.getElementById('findingsList');
  if (findings.length === 0) {
    el.innerHTML = '<p class="note">No findings on this scan — nothing to show.</p>';
    return;
  }
  const sorted = [...findings].sort((a, b) => SEV_ORDER.indexOf(safeSeverity(a.severity)) - SEV_ORDER.indexOf(safeSeverity(b.severity)));
  el.innerHTML = sorted.map((f) => {
    const sev = safeSeverity(f.severity);
    return `
    <div class="finding-card">
      <div class="finding-head">
        <span class="sev-badge ${sev}">${SEV_LABEL[sev]}</span>
        <span class="ev-badge">${escapeHtml(EV_LABEL[f.evidenceType] || EV_LABEL.detected)}</span>
        <span class="finding-title">${escapeHtml(f.title)}</span>
      </div>
      <div class="finding-evidence">${escapeHtml(f.evidence)}</div>
      ${f.remediation ? `<div class="finding-remediation">Remediation: ${escapeHtml(f.remediation)}</div>` : ''}
      <div class="finding-meta">
        <span>Category: ${escapeHtml(f.category)}</span>
        <span>Confidence: ${Math.round((Number(f.confidence) || 0) * 100)}%</span>
        <span>Evidence quality: ${Math.round((Number(f.evidenceQuality) || 0) * 100)}%</span>
        ${f.cwe ? `<span>${escapeHtml(f.cwe)}</span>` : ''}
      </div>
    </div>`;
  }).join('');
}

function renderHistory(history) {
  document.getElementById('historyBody').innerHTML = history.map((e) => `
    <tr>
      <td>${escapeHtml(fmtTime(e.timestamp))}</td>
      <td>${e.forcedAllow ? '—' : escapeHtml(e.score)}</td>
      <td>${escapeHtml(e.forcedAllow ? 'Allow-listed' : (e.band?.label || ''))}</td>
      <td>${escapeHtml(e.action)}</td>
      <td>${escapeHtml(e.findingsTotal ?? (e.findings || []).length)}</td>
    </tr>
  `).join('');
}

init();
