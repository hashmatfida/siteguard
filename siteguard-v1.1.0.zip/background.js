// SiteGuard — background service worker.
// Orchestration only: header/redirect capture -> rule engine -> scoring ->
// XAI -> badge + overlay dispatch + local history.
//
// MV3 notes
//  * The worker can be shut down at any time, so per-tab scan state lives in
//    chrome.storage.session (via lib/storage.js) with an in-memory cache in front,
//    never in a bare Map that would be lost on restart.
//  * All listeners are registered synchronously at top level (required for MV3).
//  * No alarms, no webNavigation: redirect chains are tracked from webRequest
//    events, and history retention is enforced on startup / after scans instead of
//    on a timer.

importScripts('lib/heuristics.js', 'lib/rules.js', 'lib/scoring.js', 'lib/xai.js', 'lib/storage.js');

const Store = self.SiteGuardStorage;
const Rules = self.SiteGuardRules;
const Scoring = self.SiteGuardScoring;
const XAI = self.SiteGuardXAI;
const H = self.SiteGuardHeuristics;

const ALLOW_ONCE_TTL_MS = 30 * 60 * 1000;
const MAX_REDIRECT_HOPS = 20;
const MAX_COOKIES_PARSED = 30;
const MAX_BACKEND_FINDINGS = 10;
const MAX_BACKEND_RESPONSE_CHARS = 200000;
const HTTP_FILTER = { urls: ['http://*/*', 'https://*/*'], types: ['main_frame'] };

function logError(err) { console.error('SiteGuard:', err); }

function isHttpUrl(url) {
  return typeof url === 'string' && /^https?:\/\//i.test(url);
}
function domainOf(url) {
  try { return new URL(url).hostname.toLowerCase(); } catch (_) { return ''; }
}
function originOf(url) {
  try { return new URL(url).origin; } catch (_) { return ''; }
}
function urlKey(url) {
  try { const u = new URL(url); u.hash = ''; return u.href; } catch (_) { return String(url || ''); }
}
function clip(s, n) {
  const str = String(s == null ? '' : s);
  return str.length > n ? str.slice(0, n - 1) + '…' : str;
}

// ---------------------------------------------------------------- per-tab state

// Cache in front of storage.session; the serialised queue guarantees that events for one
// tab (request start, redirect, headers, page signals, popup requests) are processed in
// the order they arrived, so none can overwrite another's update.
const tabCache = new Map();
const tabLocks = new Map();
const closedTabs = new Set();

function withTab(tabId, fn) {
  const previous = tabLocks.get(tabId) || Promise.resolve();
  const run = previous.catch(() => {}).then(async () => {
    let rec = tabCache.get(tabId);
    if (!rec) rec = (await Store.getTabState(tabId)) || {};
    const result = await fn(rec);
    if (!closedTabs.has(tabId)) {
      tabCache.set(tabId, rec);
      await Store.setTabState(tabId, rec);
    }
    return result;
  });
  tabLocks.set(tabId, run);
  return run;
}

async function peekTab(tabId) {
  if (tabId == null) return null;
  return tabCache.get(tabId) || (await Store.getTabState(tabId)) || null;
}

function resetRecord(rec, requestId, scanRequested) {
  for (const k of Object.keys(rec)) delete rec[k];
  Object.assign(rec, {
    requestId,
    redirects: [],
    scanRequested: !!scanRequested,
    analyzed: false,
    startedAt: Date.now(),
  });
}

// ---------------------------------------------------------------- navigation + header capture

chrome.webRequest.onBeforeRequest.addListener((details) => {
  if (details.tabId < 0) return;
  withTab(details.tabId, async (rec) => {
    const last = rec.redirects && rec.redirects[rec.redirects.length - 1];
    // A request that continues a redirect chain keeps the same requestId; the URL
    // comparison is a belt-and-braces fallback.
    const continuesChain = rec.requestId === details.requestId ||
      (last && last.toKey === urlKey(details.url) && Date.now() - last.at < 15000);
    if (continuesChain) { rec.requestId = details.requestId; return; }

    // New top-level navigation: start from a clean slate so signals from the PREVIOUS
    // page can never be scored together with this page's headers.
    const scanRequested = await Store.consumeRescan(details.tabId);
    resetRecord(rec, details.requestId, scanRequested);
  }).catch(logError);
}, HTTP_FILTER);

chrome.webRequest.onBeforeRedirect.addListener((details) => {
  if (details.tabId < 0) return;
  withTab(details.tabId, async (rec) => {
    if (rec.requestId && rec.requestId !== details.requestId) return; // stale event
    rec.redirects = rec.redirects || [];
    if (rec.redirects.length < MAX_REDIRECT_HOPS) {
      rec.redirects.push({
        fromHost: domainOf(details.url),
        toHost: domainOf(details.redirectUrl),
        toKey: urlKey(details.redirectUrl),
        at: Date.now(),
      });
    }
  }).catch(logError);
}, HTTP_FILTER);

chrome.webRequest.onHeadersReceived.addListener((details) => {
  if (details.tabId < 0 || details.type !== 'main_frame' || !isHttpUrl(details.url)) return;
  if (details.statusCode >= 300 && details.statusCode < 400) return; // redirect hop — see onBeforeRedirect
  const headers = parseHeaders(details.responseHeaders || []);
  withTab(details.tabId, async (rec) => {
    if (rec.requestId && rec.requestId !== details.requestId) return; // stale event
    rec.requestId = details.requestId;
    rec.url = details.url;
    rec.hostname = domainOf(details.url);
    rec.protocol = details.url.toLowerCase().startsWith('https') ? 'https:' : 'http:';
    rec.headers = headers;
    rec.analyzed = false;
    await maybeAnalyze(details.tabId, rec);
  }).catch(logError);
}, HTTP_FILTER, ['responseHeaders', 'extraHeaders']);

function parseHeaders(list) {
  const getAll = (name) => list.filter((x) => x.name.toLowerCase() === name).map((x) => x.value || '');
  const get = (name) => { const v = getAll(name); return v.length ? v[0] : null; };
  const csp = getAll('content-security-policy');
  return {
    csp: csp.length ? csp.join(', ') : null,
    hsts: get('strict-transport-security'),
    xfo: get('x-frame-options'),
    xcto: get('x-content-type-options'),
    referrerPolicy: get('referrer-policy'),
    corsAllowOrigin: get('access-control-allow-origin'),
    corsAllowCredentials: get('access-control-allow-credentials'),
    // Only attribute NAMES are kept — cookie values are discarded immediately.
    cookies: getAll('set-cookie').slice(0, MAX_COOKIES_PARSED).map(parseSetCookie),
  };
}

function parseSetCookie(raw) {
  const parts = raw.split(';').map((p) => p.trim());
  const [nameValue] = parts;
  const name = clip((nameValue || '').split('=')[0], 80);
  const lower = parts.map((p) => p.toLowerCase());
  return {
    name,
    secure: lower.some((p) => p === 'secure'),
    httpOnly: lower.some((p) => p === 'httponly'),
    sameSite: lower.some((p) => p.startsWith('samesite')),
  };
}

// Clear a stale badge as soon as a tab starts loading something new (also covers pages
// we can't analyse, e.g. chrome:// URLs, where no scan will ever replace it).
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    chrome.action.setBadgeText({ tabId, text: '' }).catch(() => {});
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  closedTabs.add(tabId);
  tabCache.delete(tabId);
  tabLocks.delete(tabId);
  Store.clearTabState(tabId).catch(() => {});
});

// ---------------------------------------------------------------- messages

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handleMessage(msg, sender).then(sendResponse).catch((err) => {
    logError(err);
    sendResponse({ ok: false, error: String(err) });
  });
  return true; // keep the channel open for the async response
});

function normalizeSignals(s) {
  if (!s || typeof s !== 'object') return null;
  const arr = (x, n) => (Array.isArray(x) ? x.slice(0, n) : []);
  return {
    forms: arr(s.forms, 20).map((f) => ({
      hasPassword: !!(f && f.hasPassword),
      actionIsCrossOrigin: !!(f && f.actionIsCrossOrigin),
      actionIsHttp: !!(f && f.actionIsHttp),
      actionOrigin: f && typeof f.actionOrigin === 'string' ? clip(f.actionOrigin, 200) : null,
    })),
    thirdPartyScripts: arr(s.thirdPartyScripts, 200).map((x) => ({ hostname: clip(x && x.hostname, 253) })),
    inlineScripts: arr(s.inlineScripts, 30).map((x) => ({
      length: Number(x && x.length) || 0,
      obfuscation: {
        score: Number(x && x.obfuscation && x.obfuscation.score) || 0,
        reasons: arr(x && x.obfuscation && x.obfuscation.reasons, 8).map((r) => clip(r, 80)),
      },
    })),
    mixedContentResources: arr(s.mixedContentResources, 50).map((x) => ({ tag: clip(x && x.tag, 20), url: clip(x && x.url, 300) })),
    iframes: arr(s.iframes, 50).map((x) => ({ hidden: !!(x && x.hidden), zeroSize: !!(x && x.zeroSize) })),
    sensitiveLinks: arr(s.sensitiveLinks, 5).map((x) => ({ href: clip(x && x.href, 300) })),
    errorTextMatches: arr(s.errorTextMatches, 3).map((x) => clip(x, 80)),
    hasMetaRefresh: !!s.hasMetaRefresh,
    isLoginOrPaymentContext: !!s.isLoginOrPaymentContext,
  };
}

async function handleMessage(msg, sender) {
  if (!msg || typeof msg.type !== 'string') return { ok: false, error: 'bad message' };
  const fromExtensionPage = typeof sender.url === 'string' && sender.url.startsWith(chrome.runtime.getURL(''));
  const contentTabId = !fromExtensionPage && sender.tab ? sender.tab.id : null;

  switch (msg.type) {
    // ---- from the content script -------------------------------------------------
    case 'SG_SIGNALS': {
      if (contentTabId == null || !isHttpUrl(msg.url)) return { ok: false };
      const signals = normalizeSignals(msg.signals);
      if (!signals) return { ok: false };
      return withTab(contentTabId, async (rec) => {
        // Ignore signals from a page that is no longer the one we captured headers for.
        if (rec.url && originOf(rec.url) !== originOf(msg.url)) return { ok: false, stale: true };
        if (rec.analyzed) return { ok: true, duplicate: true };
        rec.dom = signals;
        rec.url = rec.url || msg.url;
        rec.hostname = rec.hostname || domainOf(msg.url);
        rec.protocol = rec.protocol || (msg.url.toLowerCase().startsWith('https') ? 'https:' : 'http:');
        await maybeAnalyze(contentTabId, rec);
        return { ok: true };
      });
    }
    case 'SG_OPEN_REPORT': {
      if (contentTabId == null) return { ok: false };
      const rec = await peekTab(contentTabId);
      const domain = (rec && rec.hostname) || '';
      await chrome.tabs.create({ url: chrome.runtime.getURL(`report/report.html?domain=${encodeURIComponent(domain)}`) });
      return { ok: true };
    }
    case 'SG_ALLOW_ONCE': {
      if (contentTabId == null) return { ok: false };
      const rec = await peekTab(contentTabId);
      // Always the hostname SiteGuard itself captured for that tab — never a caller-supplied one.
      if (rec && rec.hostname) await Store.setAllowOnce(rec.hostname, ALLOW_ONCE_TTL_MS);
      return { ok: true };
    }
    case 'SG_FALSE_POSITIVE': {
      let domain = '';
      if (contentTabId != null) {
        const rec = await peekTab(contentTabId);
        domain = (rec && rec.hostname) || '';
      } else if (fromExtensionPage) {
        domain = Store.normalizeDomain(msg.domain);
      }
      if (!domain) return { ok: false };
      await Store.recordFalsePositive({ domain, source: contentTabId != null ? 'overlay' : 'popup' });
      return { ok: true };
    }

    // ---- from extension pages (popup) -------------------------------------------
    case 'SG_GET_TAB_STATE': {
      if (!fromExtensionPage) return { ok: false };
      const rec = await peekTab(msg.tabId);
      const settings = await Store.getSettings();
      return {
        ok: true,
        mode: settings.mode,
        ready: !!(rec && rec.lastResult),
        result: (rec && rec.lastResult) || null,
        hostname: (rec && rec.hostname) || null,
      };
    }
    case 'SG_SCAN_NOW': {
      // Manual mode: the popup asks for a scan of what the tab has already loaded.
      if (!fromExtensionPage || typeof msg.tabId !== 'number') return { ok: false };
      const tabId = msg.tabId;
      return withTab(tabId, async (rec) => {
        if (rec.analyzed && rec.lastResult) return { ok: true, status: 'ready' };
        rec.scanRequested = true;
        if (!rec.headers) return { ok: true, status: 'needs_reload' }; // headers are only visible during a page load
        if (!rec.dom) {
          trySend(tabId, { type: 'SG_COLLECT' }); // ask the page to send its signals again
          return { ok: true, status: 'pending' };
        }
        await maybeAnalyze(tabId, rec);
        return { ok: true, status: rec.analyzed ? 'ready' : 'pending' };
      });
    }
    case 'SG_RESCAN': {
      if (!fromExtensionPage || typeof msg.tabId !== 'number') return { ok: false };
      await Store.markRescan(msg.tabId);
      try { await chrome.tabs.sendMessage(msg.tabId, { type: 'SG_HIDE' }); } catch (_) { /* no content script */ }
      await chrome.tabs.reload(msg.tabId);
      return { ok: true };
    }
    default:
      return { ok: false, error: 'unknown message type' };
  }
}

// ---------------------------------------------------------------- analysis pipeline

async function maybeAnalyze(tabId, rec) {
  if (rec.analyzed || !rec.headers || !rec.dom) return;
  const settings = await Store.getSettings();
  // Manual mode: gather signals passively, but only analyse/store/badge when asked.
  if (settings.mode === 'manual' && !rec.scanRequested) return;
  await analyze(tabId, rec, settings);
}

function countCrossDomainHops(redirects) {
  let hops = 0;
  for (const hop of redirects || []) {
    if (hop.fromHost && hop.toHost && H.rootDomain(hop.fromHost) !== H.rootDomain(hop.toHost)) hops += 1;
  }
  return hops;
}

async function analyze(tabId, rec, settings) {
  rec.analyzed = true;
  const domain = rec.hostname;

  if (H.hostMatchesList(domain, settings.allowlist)) {
    const decision = { score: 0, band: { key: 'very_low', label: 'Very Low' }, ranked: [], action: 'allow', gate: {} };
    await finish(tabId, rec, decision, [], settings, { forcedAllow: true });
    return;
  }

  const redirects = rec.redirects || [];
  const ctx = {
    url: rec.url,
    hostname: rec.hostname,
    protocol: rec.protocol,
    headers: rec.headers,
    redirectChain: { length: redirects.length, crossDomainHops: countCrossDomainHops(redirects) },
    dom: rec.dom,
  };

  let findings = Rules.runRules(ctx);

  // Optional backend augmentation. Only used when the user has entered a backend URL AND
  // explicitly consented (Settings). Best-effort, never blocks the local pipeline, clearly
  // tagged as external/inference, skipped for private/internal hosts. The outcome is
  // recorded so the UI can tell the user when the backend was unreachable.
  let backendStatus = 'off';
  if (settings.backendUrl && settings.backendConsent === true) {
    if (H.isPrivateHost(domain)) {
      backendStatus = 'skipped_private';
    } else {
      try {
        const backendFindings = await queryBackend(settings, ctx);
        if (Array.isArray(backendFindings)) { findings = findings.concat(backendFindings); backendStatus = 'ok'; }
        else backendStatus = 'unavailable';
      } catch (_) { backendStatus = 'unavailable'; /* offline / misconfigured: degrade to local-only */ }
    }
  }

  if (H.hostMatchesList(domain, settings.denylist)) {
    findings.push({
      id: 'denylist-' + domain,
      category: 'policy',
      title: 'Domain is on your block list',
      severity: 'critical',
      confidence: 1,
      evidenceQuality: 1,
      evidenceType: 'detected',
      evidence: `"${domain}" is on your personal block list (Settings).`,
      remediation: 'Remove it from your block list if this was added in error.',
    });
  }

  const thresholds = Store.SENSITIVITY_THRESHOLDS[settings.sensitivity] || Store.SENSITIVITY_THRESHOLDS.balanced;
  const decision = Scoring.decide(findings, { thresholds });
  await finish(tabId, rec, decision, findings, settings, { backendStatus });
}

// ---------------------------------------------------------------- optional backend

const BACKEND_SEVERITIES = ['critical', 'high', 'medium', 'low', 'info'];

function num01(x, fallback) {
  return typeof x === 'number' && Number.isFinite(x) ? Math.max(0, Math.min(1, x)) : fallback;
}

// Backend output is untrusted input: validate and clamp every field before it can
// reach scoring or be rendered in an extension page.
function sanitizeBackendFinding(f, i) {
  if (!f || typeof f !== 'object') return null;
  const quality = num01(f.evidence_quality, 0.5);
  return {
    id: `backend-${i}-${clip(String(f.id || ''), 60).replace(/[^\w.-]/g, '')}`,
    category: clip(String(f.category || 'backend'), 40).replace(/[^\w -]/g, '') || 'backend',
    title: clip(f.title || f.category || 'Backend finding', 160),
    severity: BACKEND_SEVERITIES.includes(f.severity) ? f.severity : 'medium',
    confidence: num01(f.confidence, 0.6),
    evidenceQuality: quality,
    evidenceType: quality >= 0.9 ? 'external' : 'inference',
    evidence: clip(f.evidence || 'Reported by connected backend.', 300),
    remediation: clip(f.remediation || '', 300),
    cwe: typeof f.cwe === 'string' && /^CWE-\d{1,5}$/.test(f.cwe) ? f.cwe : null,
  };
}

async function queryBackend(settings, ctx) {
  const target = Store.normalizeBackendUrl(settings.backendUrl);
  if (!target.ok || !target.url) return null;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 3000);
  try {
    const res = await fetch(`${target.url}/v1/scan/quick`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(settings.backendToken ? { Authorization: `Bearer ${settings.backendToken}` } : {}),
      },
      credentials: 'omit',
      cache: 'no-store',
      redirect: 'error',
      body: JSON.stringify({
        domain: ctx.hostname,
        protocol: ctx.protocol.replace(':', ''),
        // Minimised feature vector only — no URLs, page content, or cookie values.
        features: {
          has_hsts: !!ctx.headers.hsts,
          csp_present: !!ctx.headers.csp,
          mixed_content_count: (ctx.dom.mixedContentResources || []).length,
          redirect_chain_len: ctx.redirectChain.length,
          redirect_cross_domain_hops: ctx.redirectChain.crossDomainHops,
          third_party_script_count: (ctx.dom.thirdPartyScripts || []).length,
          form_has_password_field: (ctx.dom.forms || []).some((f) => f.hasPassword),
        },
      }),
      signal: controller.signal,
    });
    if (!res.ok) return null;
    const text = await res.text();
    if (text.length > MAX_BACKEND_RESPONSE_CHARS) return null;
    const data = JSON.parse(text);
    const list = Array.isArray(data && data.top_findings) ? data.top_findings.slice(0, MAX_BACKEND_FINDINGS) : [];
    return list.map(sanitizeBackendFinding).filter(Boolean);
  } finally {
    clearTimeout(timeout);
  }
}

// ---------------------------------------------------------------- results

function compactFinding(f) {
  return {
    id: f.id,
    category: clip(f.category, 40),
    title: clip(f.title, 160),
    severity: f.severity,
    confidence: f.confidence,
    evidenceQuality: f.evidenceQuality,
    evidence: clip(f.evidence, 300),
    evidenceType: f.evidenceType,
    remediation: clip(f.remediation, 300),
    cwe: f.cwe || null,
  };
}

// The record kept in history and shown by the popup/report. Deliberately compact (the
// extension's storage quota is finite) and free of query strings / fragments.
function buildHistoryEntry(rec, decision, findings, explanation, flags) {
  return {
    url: Store.sanitizeUrl(rec.url),
    score: decision.score,
    band: decision.band,
    action: flags.forcedAllow ? 'allow' : decision.action,
    forcedAllow: !!flags.forcedAllow,
    backend: flags.backendStatus || 'off', // 'off' | 'ok' | 'unavailable' | 'skipped_private'
    findingsTotal: findings.length,
    findings: findings.slice(0, 40).map(compactFinding),
    explanation: {
      headline: explanation.headline,
      recommendation: explanation.recommendation,
      factors: explanation.factors.slice(0, 3).map((f) => ({
        title: clip(f.title, 160),
        contributionLabel: f.contributionLabel,
        evidenceTypeLabel: f.evidenceTypeLabel,
        evidence: clip(f.evidence, 300),
      })),
    },
  };
}

async function finish(tabId, rec, decision, findings, settings, flags) {
  const domain = rec.hostname;
  const explanation = XAI.explain(decision, domain);
  if (flags.forcedAllow) {
    explanation.headline = 'On your allow list';
    explanation.recommendation = 'This domain is on your allow list, so SiteGuard did not scan it and will never warn or block here.';
  }

  const entry = buildHistoryEntry(rec, decision, findings, explanation, flags);
  rec.lastResult = { ...entry, timestamp: Date.now() };
  // Raw headers and page signals are no longer needed once the verdict exists.
  rec.headers = null;
  rec.dom = null;

  await setBadge(tabId, decision, flags.forcedAllow);

  try {
    await Store.pushHistory(domain, entry);
    Store.maybePrune().catch(logError); // enforces retention for ALL domains, at most once a day
  } catch (err) {
    logError(err); // storage trouble must not prevent the warning from showing
  }

  if (flags.forcedAllow || settings.mode !== 'auto') return;
  if (await Store.isAllowedOnce(domain)) return;

  if (decision.action === 'block' && settings.autoBlockCritical) {
    const policyLocked = decision.score >= 90; // very high scores: discourage silent dismissal
    trySend(tabId, { type: 'SG_SHOW_BLOCK', explanation, policyLocked });
  } else if (decision.action === 'warn' || decision.action === 'block') {
    trySend(tabId, { type: 'SG_SHOW_WARN', explanation });
  }
}

function trySend(tabId, message) {
  chrome.tabs.sendMessage(tabId, message, () => void chrome.runtime.lastError);
}

async function setBadge(tabId, decision, forcedAllow) {
  const colors = {
    very_low: '#5a9e6f', low: '#5a9e6f', moderate: '#d9932c', high: '#c0392b', critical: '#8e1f16',
  };
  const key = forcedAllow ? 'very_low' : decision.band.key;
  const text = forcedAllow || decision.score < 15 ? '' : String(decision.score);
  try {
    await chrome.action.setBadgeText({ tabId, text });
    await chrome.action.setBadgeBackgroundColor({ tabId, color: colors[key] || '#5a5a5a' });
  } catch (_) { /* tab may have closed */ }
}

// ---------------------------------------------------------------- declarativeNetRequest (block list)

let ruleSyncChain = Promise.resolve();
function syncDenylistRules() {
  const run = ruleSyncChain.then(doSyncDenylistRules, doSyncDenylistRules);
  ruleSyncChain = run.catch(() => {});
  return run;
}

async function doSyncDenylistRules() {
  const settings = await Store.getSettings();
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const domains = settings.denylist; // already validated + de-duplicated by storage.sanitizeSettings

  const haveSame = existing.length === domains.length &&
    existing.every((r, i) => r.condition && r.condition.requestDomains && r.condition.requestDomains[0] === domains[i]);
  if (haveSame) return;

  const removeRuleIds = existing.map((r) => r.id);
  const addRules = domains.map((domain, i) => ({
    id: i + 1,
    priority: 1,
    action: { type: 'block' },
    condition: { requestDomains: [domain], resourceTypes: ['main_frame'] },
  }));

  try {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
  } catch (err) {
    // One bad entry makes the whole batch fail — fall back to adding rules one by one so
    // a single invalid domain can never disable every other block rule.
    console.warn('SiteGuard: batch rule update failed, retrying individually', err);
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: [] });
    for (const rule of addRules) {
      try { await chrome.declarativeNetRequest.updateDynamicRules({ addRules: [rule] }); }
      catch (e) { console.warn('SiteGuard: skipped invalid block rule', rule.condition.requestDomains, e); }
    }
  }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  const change = changes[Store.SG_KEYS.settings];
  if (!change) return;
  const before = change.oldValue || {};
  const after = change.newValue || {};
  if (JSON.stringify(before.denylist || []) !== JSON.stringify(after.denylist || [])) {
    syncDenylistRules().catch(logError);
  }
  if (before.retentionDays !== after.retentionDays) {
    Store.pruneExpiredHistory().catch(logError);
  }
});

// ---------------------------------------------------------------- lifecycle

chrome.runtime.onInstalled.addListener(async (details) => {
  try {
    await Store.ensureInstalled();
    if (details && details.reason === 'update') await Store.scrubHistoryUrls(); // v1.0 stored full URLs
    await syncDenylistRules();
    await Store.pruneExpiredHistory();
  } catch (err) {
    logError(err);
  }
});

chrome.runtime.onStartup.addListener(() => {
  syncDenylistRules().catch(logError);
  Store.maybePrune().catch(logError);
});
