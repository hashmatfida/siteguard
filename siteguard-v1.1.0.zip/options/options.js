const S = SiteGuardStorage;

const els = {
  mode: document.getElementById('mode'),
  sensitivity: document.getElementById('sensitivity'),
  autoBlockCritical: document.getElementById('autoBlockCritical'),
  retentionDays: document.getElementById('retentionDays'),
  backendUrl: document.getElementById('backendUrl'),
  backendToken: document.getElementById('backendToken'),
  backendError: document.getElementById('backendError'),
  backendConsent: document.getElementById('backendConsent'),
  allowInput: document.getElementById('allowInput'),
  allowAdd: document.getElementById('allowAdd'),
  allowList: document.getElementById('allowList'),
  allowError: document.getElementById('allowError'),
  denyInput: document.getElementById('denyInput'),
  denyAdd: document.getElementById('denyAdd'),
  denyList: document.getElementById('denyList'),
  denyError: document.getElementById('denyError'),
  clearHistory: document.getElementById('clearHistory'),
  savedNote: document.getElementById('savedNote'),
};

let savedTimer = null;

function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function flash(text = 'Saved ✓') {
  els.savedNote.textContent = text;
  els.savedNote.classList.remove('hidden');
  clearTimeout(savedTimer);
  savedTimer = setTimeout(() => els.savedNote.classList.add('hidden'), 1600);
}

function setError(el, message) {
  el.textContent = message || '';
  el.classList.toggle('hidden', !message);
}

function renderChips(listEl, items, listName) {
  listEl.innerHTML = items.map((d) => `
    <li>${escapeHtml(d)}<button data-domain="${escapeHtml(d)}" data-list="${listName}" aria-label="Remove ${escapeHtml(d)}">✕</button></li>
  `).join('') || '<li style="color:#999;background:none;border:none;">none</li>';
}

async function load() {
  const settings = await S.getSettings();
  els.mode.value = settings.mode;
  els.sensitivity.value = settings.sensitivity;
  els.autoBlockCritical.checked = settings.autoBlockCritical;
  els.retentionDays.value = String(settings.retentionDays);
  els.backendUrl.value = settings.backendUrl || '';
  els.backendToken.value = settings.backendToken || '';
  els.backendConsent.checked = settings.backendConsent;
  els.backendConsent.disabled = !settings.backendUrl; // consent is only meaningful once a URL is saved
  renderChips(els.allowList, settings.allowlist, 'allowlist');
  renderChips(els.denyList, settings.denylist, 'denylist');
}

async function save(partial) {
  await S.saveSettings(partial);
  flash();
}

els.mode.addEventListener('change', () => save({ mode: els.mode.value }));
els.sensitivity.addEventListener('change', () => save({ sensitivity: els.sensitivity.value }));
els.autoBlockCritical.addEventListener('change', () => save({ autoBlockCritical: els.autoBlockCritical.checked }));
els.retentionDays.addEventListener('change', () => save({ retentionDays: Number(els.retentionDays.value) }));
els.backendConsent.addEventListener('change', () => save({ backendConsent: els.backendConsent.checked }));
els.backendToken.addEventListener('change', () => save({ backendToken: els.backendToken.value.trim() }));

els.backendUrl.addEventListener('change', async () => {
  const result = S.normalizeBackendUrl(els.backendUrl.value);
  if (!result.ok) {
    setError(els.backendError, result.error);
    return; // nothing is saved until the URL is valid
  }
  setError(els.backendError, '');
  els.backendUrl.value = result.url;
  // Consent is per server: pointing SiteGuard at a different server (or clearing it) resets consent.
  const current = await S.getSettings();
  if (current.backendUrl === result.url) {
    await load();
    return;
  }
  await save({ backendUrl: result.url, backendConsent: false });
  await load();
});

async function addDomain(inputEl, errorEl, listName, otherListName) {
  const domain = S.normalizeDomain(inputEl.value);
  if (!domain) {
    setError(errorEl, 'Enter a valid domain such as example.com (IP addresses are fine too).');
    return;
  }
  setError(errorEl, '');
  // A domain can only be on one list: an allow-listed domain on the block list (or vice versa) would contradict itself.
  await S.removeFromList(domain, otherListName);
  await S.addToList(domain, listName);
  inputEl.value = '';
  await load();
  flash();
}

els.allowAdd.addEventListener('click', () => addDomain(els.allowInput, els.allowError, 'allowlist', 'denylist'));
els.denyAdd.addEventListener('click', () => addDomain(els.denyInput, els.denyError, 'denylist', 'allowlist'));
els.allowInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') els.allowAdd.click(); });
els.denyInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') els.denyAdd.click(); });

document.addEventListener('click', async (e) => {
  const btn = e.target.closest('button[data-domain]');
  if (!btn) return;
  await S.removeFromList(btn.dataset.domain, btn.dataset.list);
  await load();
});

els.clearHistory.addEventListener('click', async () => {
  if (!confirm('Delete all locally stored scan history? This cannot be undone.')) return;
  await S.clearHistory();
  flash('Scan history cleared ✓');
});

load();
