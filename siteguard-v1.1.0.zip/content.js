// SiteGuard — content script.
// Runs once per top-level page load (see manifest: all_frames=false). Loaded after
// lib/heuristics.js, which provides the shared detection patterns.
// Job 1: passively collect DOM-visible signals and hand them to the background
//        service worker. Never sends cookie values, query strings, or page text —
//        only small, capped, structured signals.
// Job 2: render the warn/block UI inline, isolated in a Shadow DOM so we
//        never collide with the host page's styles.

(function () {
  if (window.__siteguardInjected) return;
  window.__siteguardInjected = true;

  const H = self.SiteGuardHeuristics;
  if (!H) return; // heuristics failed to load — fail closed (no scan) rather than throw on every page

  const LOGIN_CONTEXT_RE = /log ?in|sign ?in|checkout|payment|card ?number|cvv|billing/i;

  const MAX_LINKS_SCANNED = 2000;
  const MAX_INLINE_SCRIPTS = 100;
  const MAX_INLINE_SCRIPT_CHARS = 50000;
  const MAX_ITEMS = 50;

  /** origin + path only — query strings and fragments can carry tokens or personal data. */
  function stripQuery(raw) {
    try {
      const u = new URL(raw, location.href);
      return u.origin + u.pathname;
    } catch (_) {
      return String(raw || '').split(/[?#]/)[0];
    }
  }

  function collectSignals() {
    const pageIsHttps = location.protocol === 'https:';

    const forms = Array.from(document.forms).slice(0, 20).map((form) => {
      const hasPassword = !!form.querySelector('input[type="password"]');
      let actionIsCrossOrigin = false, actionIsHttp = false, actionOrigin = null;
      try {
        const actionUrl = new URL(form.action || location.href, location.href);
        actionOrigin = actionUrl.origin;
        actionIsCrossOrigin = actionUrl.origin !== location.origin;
        actionIsHttp = actionUrl.protocol === 'http:';
      } catch (_) { /* ignore malformed action */ }
      return { hasPassword, actionIsCrossOrigin, actionIsHttp, actionOrigin };
    });

    const scriptEls = Array.from(document.querySelectorAll('script'));
    const thirdPartyHosts = new Set();
    const inlineScripts = [];
    for (const el of scriptEls) {
      if (el.src) {
        try {
          const u = new URL(el.src, location.href);
          if (u.origin !== location.origin) thirdPartyHosts.add(u.hostname);
        } catch (_) { /* ignore */ }
      } else if (inlineScripts.length < MAX_INLINE_SCRIPTS && el.textContent && el.textContent.length > 40) {
        inlineScripts.push({
          length: el.textContent.length,
          obfuscation: H.scriptObfuscationScore(el.textContent.slice(0, MAX_INLINE_SCRIPT_CHARS)),
        });
      }
    }
    // Keep only the most suspicious inline scripts (the rule engine only looks at the worst one).
    inlineScripts.sort((a, b) => b.obfuscation.score - a.obfuscation.score);

    const mixedContentResources = [];
    if (pageIsHttps) {
      const tagsToCheck = [
        ['img[src]', 'img', 'src'],
        ['script[src]', 'script', 'src'],
        ['iframe[src]', 'iframe', 'src'],
        ['link[rel="stylesheet"][href]', 'link', 'href'],
        ['video[src]', 'video', 'src'],
        ['audio[src]', 'audio', 'src'],
      ];
      for (const [selector, tag, attr] of tagsToCheck) {
        for (const el of document.querySelectorAll(selector)) {
          if (mixedContentResources.length >= MAX_ITEMS) break;
          const raw = el.getAttribute(attr);
          if (raw && /^http:\/\//i.test(raw)) mixedContentResources.push({ tag, url: stripQuery(raw) });
        }
      }
    }

    const iframes = Array.from(document.querySelectorAll('iframe')).slice(0, MAX_ITEMS).map((f) => {
      const rect = f.getBoundingClientRect();
      const style = window.getComputedStyle(f);
      const zeroSize = rect.width <= 1 || rect.height <= 1;
      const hidden = style.visibility === 'hidden' || style.display === 'none' || parseFloat(style.opacity || '1') === 0;
      return { hidden, zeroSize };
    });

    const sensitiveLinks = [];
    const anchors = document.querySelectorAll('a[href]');
    const anchorLimit = Math.min(anchors.length, MAX_LINKS_SCANNED);
    outer: for (let i = 0; i < anchorLimit; i++) {
      const href = anchors[i].getAttribute('href') || '';
      for (const re of H.SENSITIVE_PATH_PATTERNS) {
        if (re.test(href)) { sensitiveLinks.push({ href: stripQuery(href) }); break outer; }
      }
    }

    let bodyText = '';
    try { bodyText = ((document.body && document.body.innerText) || '').slice(0, 20000); } catch (_) { /* ignore */ }
    // Only a fixed label is recorded — never text copied from the page.
    const errorTextMatches = [];
    for (const sig of H.ERROR_SIGNATURES) {
      if (sig.re.test(bodyText)) { errorTextMatches.push(sig.label); break; }
    }

    const hasMetaRefresh = !!document.querySelector('meta[http-equiv="refresh" i]');
    const isLoginOrPaymentContext =
      forms.some((f) => f.hasPassword) || LOGIN_CONTEXT_RE.test(document.title + ' ' + location.href);

    return {
      forms,
      thirdPartyScripts: Array.from(thirdPartyHosts).map((hostname) => ({ hostname })),
      inlineScripts: inlineScripts.slice(0, 30),
      mixedContentResources,
      iframes,
      sensitiveLinks,
      errorTextMatches,
      hasMetaRefresh,
      isLoginOrPaymentContext,
    };
  }

  function send() {
    try {
      chrome.runtime.sendMessage({ type: 'SG_SIGNALS', signals: collectSignals(), url: location.href }, () => {
        // Swallow "no receiving end" errors that can happen on extension reload.
        void chrome.runtime.lastError;
      });
    } catch (_) { /* extension context may be invalidated during reload */ }
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(send, 50);
  } else {
    document.addEventListener('DOMContentLoaded', () => setTimeout(send, 50));
  }

  // ---------------------------------------------------------------- UI overlay

  let shadowHost = null;
  let shadowRoot = null;

  function ensureShadow() {
    if (shadowRoot) return shadowRoot;
    shadowHost = document.createElement('div');
    shadowHost.id = 'siteguard-shadow-host';
    shadowHost.style.all = 'initial';
    document.documentElement.appendChild(shadowHost);
    shadowRoot = shadowHost.attachShadow({ mode: 'closed' });
    return shadowRoot;
  }

  function styles() {
    return `
      :host { all: initial; }
      * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; }
      .sg-banner {
        position: fixed; top: 0; left: 0; right: 0; z-index: 2147483000;
        background: #fff7e0; border-bottom: 3px solid #d9932c; color: #4a3a10;
        padding: 10px 16px; display: flex; align-items: center; gap: 12px;
        font-size: 13.5px; box-shadow: 0 2px 8px rgba(0,0,0,.15);
      }
      .sg-banner.critical { background: #fdecec; border-bottom-color: #c0392b; color: #4a1210; }
      .sg-banner .sg-icon { font-size: 18px; }
      .sg-banner .sg-msg { flex: 1; line-height: 1.4; }
      .sg-banner .sg-msg b { display:block; font-size: 14px; margin-bottom: 2px; }
      .sg-btn {
        border: 1px solid rgba(0,0,0,.2); background: rgba(255,255,255,.6); color: inherit;
        padding: 6px 12px; border-radius: 6px; font-size: 12.5px; cursor: pointer; white-space: nowrap;
      }
      .sg-btn.primary { background: #1b2a4a; color: #fff; border-color: #1b2a4a; }
      .sg-btn:hover { filter: brightness(0.95); }
      .sg-btn:focus-visible, .sg-links a:focus-visible { outline: 2px solid #2b6fff; outline-offset: 2px; }
      .sg-overlay {
        position: fixed; inset: 0; z-index: 2147483647; background: #10131c;
        display: flex; align-items: center; justify-content: center; padding: 24px; overflow: auto;
      }
      .sg-card {
        max-width: 560px; width: 100%; background: #fff; border-radius: 12px; padding: 32px;
        box-shadow: 0 20px 60px rgba(0,0,0,.4); color: #1c2333;
      }
      .sg-card .sg-brand { font-size: 12px; font-weight: 700; color: #1b2a4a; margin-bottom: 12px; letter-spacing: .02em; }
      .sg-card .sg-origin { font-size: 11.5px; color: #667; margin-top: 16px; }
      .sg-card .sg-badge {
        display: inline-block; padding: 3px 10px; border-radius: 999px; font-size: 11.5px;
        font-weight: 700; letter-spacing: .04em; text-transform: uppercase; background: #fdecec; color: #a5241a;
        margin-bottom: 14px;
      }
      .sg-card h1 { font-size: 20px; margin: 0 0 8px 0; color: #1b1620; }
      .sg-card .sg-domain { font-size: 13px; color: #666; margin-bottom: 18px; word-break: break-all; }
      .sg-card .sg-score { font-size: 15px; margin-bottom: 14px; }
      .sg-card .sg-score b { font-size: 26px; }
      .sg-reasons { list-style: none; padding: 0; margin: 0 0 20px 0; }
      .sg-reasons li { padding: 9px 0; border-top: 1px solid #eee; font-size: 13px; }
      .sg-reasons li:first-child { border-top: none; }
      .sg-reasons .sg-tag {
        display: inline-block; font-size: 10.5px; font-weight: 700; text-transform: uppercase;
        padding: 1px 6px; border-radius: 4px; margin-right: 6px; background: #eef0f6; color: #445;
      }
      .sg-actions { display: flex; gap: 10px; margin-top: 22px; flex-wrap: wrap; }
      .sg-actions .sg-btn { flex: 1; text-align: center; padding: 10px 14px; font-size: 13.5px; }
      .sg-links { margin-top: 14px; font-size: 12px; color: #667; display:flex; gap: 14px; }
      .sg-links a { color: #445; cursor: pointer; text-decoration: underline; }
    `;
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function reasonsHtml(factors) {
    return (factors || []).slice(0, 4).map((f) => `
      <li>
        <span class="sg-tag">${escapeHtml(f.contributionLabel)}</span>
        <span class="sg-tag" style="background:#f4f6fb;color:#2b3a67;">${escapeHtml(f.evidenceTypeLabel)}</span>
        <div style="margin-top:4px;"><strong>${escapeHtml(f.title)}</strong></div>
        <div style="color:#556;margin-top:2px;">${escapeHtml(f.evidence)}</div>
      </li>
    `).join('');
  }

  function showBanner(explanation) {
    const root = ensureShadow();
    const isCritical = explanation.band.key === 'critical';
    root.innerHTML = `<style>${styles()}</style>
      <div class="sg-banner ${isCritical ? 'critical' : ''}" role="alert">
        <span class="sg-icon" aria-hidden="true">${isCritical ? '⛔' : '⚠️'}</span>
        <div class="sg-msg">
          <b>SiteGuard: ${escapeHtml(explanation.headline)}</b>
          ${escapeHtml((explanation.factors[0] && explanation.factors[0].title) || '')}
        </div>
        <button class="sg-btn" id="sg-details">View details</button>
        <button class="sg-btn primary" id="sg-dismiss">Dismiss</button>
      </div>`;
    root.getElementById('sg-dismiss').onclick = () => hide();
    root.getElementById('sg-details').onclick = () => chrome.runtime.sendMessage({ type: 'SG_OPEN_REPORT' });
  }

  function showBlockOverlay(explanation, policyLocked) {
    const root = ensureShadow();
    const confidence = Math.round((((explanation.factors[0] || {}).confidence) || 0.8) * 100);
    root.innerHTML = `<style>${styles()}</style>
      <div class="sg-overlay" role="alertdialog" aria-modal="true" aria-labelledby="sg-title">
        <div class="sg-card">
          <div class="sg-brand">🛡 SiteGuard extension</div>
          <span class="sg-badge">${escapeHtml(explanation.band.label)} risk</span>
          <h1 id="sg-title">SiteGuard flagged this site as risky</h1>
          <div class="sg-domain">${escapeHtml(explanation.domain)}</div>
          <div class="sg-score">Risk score <b>${Number(explanation.score) || 0}</b>/100 &middot; confidence ${confidence}%</div>
          <ul class="sg-reasons">${reasonsHtml(explanation.factors)}</ul>
          <div class="sg-actions">
            <button class="sg-btn primary" id="sg-back">Go back</button>
            ${policyLocked ? '' : '<button class="sg-btn" id="sg-continue">Continue anyway</button>'}
          </div>
          <div class="sg-origin">This message comes from the SiteGuard browser extension, not from Chrome or your operating system.</div>
          <div class="sg-links">
            <a id="sg-report" role="button" tabindex="0">View detailed report</a>
            <a id="sg-fp" role="button" tabindex="0">Mark as false positive</a>
          </div>
        </div>
      </div>`;
    const back = root.getElementById('sg-back');
    back.onclick = () => { if (history.length > 1) history.back(); else window.close(); };
    const cont = root.getElementById('sg-continue');
    if (cont) cont.onclick = () => {
      chrome.runtime.sendMessage({ type: 'SG_ALLOW_ONCE' });
      hide();
    };
    const activate = (el, fn) => {
      el.onclick = fn;
      el.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fn(); } };
    };
    activate(root.getElementById('sg-report'), () => chrome.runtime.sendMessage({ type: 'SG_OPEN_REPORT' }));
    activate(root.getElementById('sg-fp'), () => {
      chrome.runtime.sendMessage({ type: 'SG_FALSE_POSITIVE' });
      const fp = root.getElementById('sg-fp');
      if (fp) { fp.textContent = 'Saved on this device'; fp.onclick = null; fp.onkeydown = null; }
    });
    back.focus();
  }

  function hide() {
    if (shadowHost) { shadowHost.remove(); shadowHost = null; shadowRoot = null; }
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || typeof msg.type !== 'string') return false;
    if (msg.type === 'SG_SHOW_WARN') { showBanner(msg.explanation); sendResponse({ ok: true }); }
    else if (msg.type === 'SG_SHOW_BLOCK') { showBlockOverlay(msg.explanation, msg.policyLocked); sendResponse({ ok: true }); }
    else if (msg.type === 'SG_HIDE') { hide(); sendResponse({ ok: true }); }
    else if (msg.type === 'SG_COLLECT') { send(); sendResponse({ ok: true }); }
    return false; // every response above is synchronous — don't hold the message channel open
  });
})();
